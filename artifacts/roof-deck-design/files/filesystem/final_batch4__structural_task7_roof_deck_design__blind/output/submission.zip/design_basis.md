# DC-2 Helena Data Centre, Building A - Roof Deck Design Basis

Project DC2-2026-014. Roof deck: NORDECK B-36, 1-1/2 in wide-rib (Type B), 36 in cover, laid across 26K9 joists at 6 ft-0 in in 3-span continuous lengths. Joists, joist girders, edge angle, collectors and braced frames are fixed and were not changed. All plan coordinates are project grid feet, origin at grid 1-A, x along grids 1 to 9, y along grids A to G.

## 1. Governing documents and how conflicts were resolved

* **Transmittal T-118 (01 Aug 2026)** sets the current revision of every document. Only those revisions were used: A-201 Rev C, S-101 Rev 3, S-501 Rev 2, M-401 Rev C, EOR-DC-RD-01 Rev 2, LAT-2026-003 Rev 1, SNOW-2026-014 Rev 0, DC2-A-STR Rev C (IFC) and CP-RD-2026 Rev 0.
* **Geometry of record = IFC model DC2-A-STR Rev C** (T-118 note 3.1; model note section 5). Lengths were read from the IFC geometry in millimetres and divided by 304.8. The model places the north screen wall SCR-N at y = 163.67 to 164.33 ft (x = 18 to 222 ft), which matches A-201 Rev C. **A-201 Rev B** (in `archive/`) shows SCR-N at y = 158 ft and is superseded (T-118 note 3.2), so it was not used for drifts or zoning. SCR-E is at x = 215.67 to 216.33 ft, y = 24 to 144 ft. The framed openings in the model (RO-1 96-108 x 48-60, RO-2 132-144 x 120-132, RO-3 180-210 x 60-80) agree with S-101 Rev 3 and A-201 Rev C. Rooftop-unit plan positions and heights in the model agree with M-401 Rev C and the equipment schedule. I used the unit bodies, not the dashed curb outlines on M-401, because the model is the geometry of record. The two DC-1 Building B rows in the equipment schedule belong to another building and were ignored.
* **EOR-DC-RD-01 Rev 2** governs loads, combinations and deck rules. **Rev 1** (archive) is withdrawn in full (T-118 note 3.3). In particular, its reduced deck live load of 12 psf and its effective seismic weight without snow were **not** used.
* **UFC 3-301-01** is the DoD overlay (criteria clause 1.2). Roof live load comes from UFC Table E-1 item 51 (20 psf, unreduced on the deck per criteria 4.2). The ground-snow case study is on an RC II basis (UFC 1608.2.3). Snow build-up at obstructions follows UFC 3-4.1. The deck is not thinner than 22 gage (UFC 2208.1 supplement). Thermal effects are excluded by the AHJ agreement recorded in OBD section 9 and criteria 1.5. UFC 2.3.4 asks that the effect of T be considered: it was, and the insulated, continuously conditioned roof assembly is why the AHJ excluded it.
* **Hall A deck design (Butte, 2019)** is an archive precedent for another building, site and risk category, with a discontinued product. It was not used.
* **USGS data**: the ASCE 7-22, RC III, Site Class D file gives SDS = 0.44 and SD1 = 0.24, matching criteria 7.1. The 2019 preliminary ASCE 7-16, RC II, Site Class C file (SDS = 0.407) does not apply. The Canyon Ferry Dam SWE series is a supporting record only; SNOW-2026-014 is the only source of pg (OBD section 9).
* **Procurement**: 16 gage has a 14-week mill lead time, which exceeds the 9-week release-to-site allowance (OBD section 5; stock sheet), so it is not available. 22, 20 and 18 gage are ex stock. Button-punch sidelaps are not permitted on 18 gage (catalogue 6.4 note), so all 18 gage zones use SCREW-10.
* **Catalogue values** were reproduced from the printed bases (clauses 3.1, 3.3, 5.2, 6.2), as criteria 10.1 requires. Every Sn, G', allowable load and pull-over value used matches the tables.

## 2. Snow basis

pg = 63 psf (SNOW-2026-014, RC II basis, AHJ accepted). The importance factor is applied once. pf = 0.7 Ce Ct Is pg = 0.7 x 0.90 x 1.0 x 1.10 x 63 = **43.66 psf**. Snow density gamma = 0.13 x 63 + 14 = **22.19 pcf**, so hb = 1.968 ft. Drift height is hd = 0.43 lu^(1/3) (pg + 10)^(1/4) - 1.5, with lu not less than 20 ft. For each obstruction and each of the four wind directions:

* windward face: 0.75 hd, with lu = fetch from the upwind roof edge;
* sheltered face: hd, with lu = along-wind length of the obstruction;
* triangular shape, truncated at hc = h - hb where hd > hc.

The four directions are enveloped, not added. Obstructions in the same scenario are also enveloped (largest surcharge at each point). Every obstruction has hc greater than 2.0 ft (smallest: SCR-N at 4.03 ft), so all receive the full treatment. The parapet (3.5 ft, hc = 1.53 ft) follows the windward rule of clause 5.4.6, with lu = 180 ft (north/south) and 240 ft (east/west). It truncates to a 34.0 psf peak over 12.26 ft.

| Location | Face | Rule | lu (ft) | Drift height (ft) | Peak surcharge (psf) | Band (ft) |
|---|---|---|---|---|---|---|
| MEP-PH-1 | W | leeward | 120.0 | 4.700 | 104.3 | 60.00 to 41.20 |
| SCR-N | S | windward | 163.7 | 4.031 | 89.5 | 163.67 to 147.54 |
| PARAPET | N | windward | 180.0 | 4.198 | 34.0 | 179.33 to 167.07 |
| RTU-1 | E | windward | 204.0 | 4.424 | 98.2 | 36.00 to 53.70 |

Other governing drifts:

* MEP-PH-1 east face: same as the west face, 104.3 psf.
* MEP-PH-1 north and south faces: 75.9 psf leeward, w = 13.68 ft.
* SCR-N ends: 89.5 psf leeward, lu = 204 ft, w = 32.26 ft.
* SCR-E: west face 100.5 psf windward; north and south ends 104.3 psf leeward (lu = 120 ft).
* Rooftop units: windward faces with long fetches reach 85-98 psf.

Scenario demands:

* S01: D + Lr = 10.5 psf + deck + 20 psf.
* S02 to S04: D + pf + drift.

Allowable total loads at 6 ft (Fb = 23.95 ksi, M = wL^2/10): 22 ga 106.4 psf, 20 ga 130.3 psf, 18 ga 176.9 psf. The L/240 deflection limits on live or snow load (3-span, delta = 0.0069 wL^4/EI, E = 29,500 ksi) are 96.8, 119.1 and 163.2 psf. Allowable drift surcharge above pf is therefore 50.7 psf (22 ga), 74.2 psf (20 ga) and 119.6 psf (18 ga). Each 6 ft x 6 ft cell carries the worst surcharge anywhere inside it (criteria 5.4.7). End reactions (1.1wL at the interior support) are below Table 4-1 in every zone. Bearing is 1.5 in per S-501 detail 1 and joist schedule note N1, with deck ends lapped over the 2.5 in joist top chord.

## 3. Wind uplift basis

qh = 0.00256 x 1.04 x 1.0 x 0.85 x 1.0 x 115^2 = 29.93 psf. a = 12.8 ft. Net uplift from Table 6-2 (GCpi = +0.18 adverse):

* Zone 3 (corner squares a x a): 101.2 psf;
* Zone 2 (perimeter band a): 74.2 psf;
* Zone 1 (band a to 2a): 47.3 psf;
* Zone 1-prime (interior): 32.3 psf.

Capacity = 0.5 x Pnov x n / (3 ft x 6 ft) + 0.9 x (deck + 4.5 psf roofing); the MEP allowance is excluded. Any cell touched by a pressure zone takes that zone's pressure, so the corner zone covers 18 ft x 18 ft of cells, zone 2 an 18 ft band and zone 1 the band to 30 ft. Only 18 ga at 36/9 (126.0 psf) can resist the 101.2 psf corner uplift: 16 ga is unavailable, and 18 ga at 36/7 gives only 99.4 psf. In the zone 2 band, 22 ga needs 36/9 (80.0 psf).

## 4. Seismic basis

SDS = 0.44, Ie = 1.25, R = 3.25, rho = 1.0, Omega0 = 2.0 (criteria 7.1; LAT section 5). pf = 43.66 psf exceeds 30 psf, so criteria 7.2 adds 20 per cent of pf to the 18 psf roof dead weight (LAT Table 5-2): W = 18 + 0.2 x 43.66 = **26.73 psf** over the 240 ft x 180 ft plan, 1154.8 kip in total. Cs = SDS Ie / R = 0.1692, which lies between 0.2 SDS Ie = 0.110 and 0.4 SDS Ie = 0.220. Fpx = V = 0.1692 x 1154.8 = **195.4 kip**. Fpx is spread over the plan by tributary area, with accidental torsion of 0.05 x plan dimension (9 ft for x, 12 ft for y) applied as a plan couple in both senses.

## 5. Diaphragm analysis and classification

The in-plane model follows LAT sections 6.3 and 7 and the criteria.

* **Shear panels:** 6 ft (one joist bay) x 30 ft (one girder bay). Each panel carries pure shear. Its G' is the series combination of the 6 ft x 6 ft deck cells stacked across its depth, using the G' of the zone specification. A panel touching an opening carries no shear.
* **Axial bars:** every joist line (EA 87,580 kip) and every girder line (EA 221,850 kip). The L5x3-1/2x5/16 perimeter member (EA 74,240 kip) is added on all four boundary lines.
* **Braced frames:** each modelled as springs of k/2 at its two column lines (Table 3-1).
* **Regularisation:** a 1e-6 kip/in spring on every degree of freedom. It carries less than 0.001 per cent of the load in every case, so a real load path exists.

Load cases:

* **Wind (Table 4-1):** 118.0 kip along x and 152.0 kip along y, applied half on each wall line perpendicular to the force. Case 1 is analysed, plus case 2 (75 per cent with 0.15 x plan dimension eccentricity, both senses), and the envelope is reported.
* **Seismic:** S07/S08 with both eccentricity senses. S10 is S07 with the collector force multiplied by Omega0 = 2.0.

Reported quantities:

* **Chord force:** the largest axial force in the perimeter line parallel to the diaphragm span. For x the lines are grids 1 and 9; for y they are grids A and G.
* **Collector force:** the largest perimeter-line axial force within one bay of a braced frame of that direction.

Both are taken as the total force in the boundary line (girder or joist plus edge member). This is conservative against the 38.0 kip chord splice and the 58.0 kip collector splice.

| Scenario | Dir | Max shear (plf) | Diaphragm deflection (in) | Avg frame drift (in) | Chord (kip) | Collector (kip) | Class |
|---|---|---|---|---|---|---|---|
| S05 | x | 369 | 0.51 | 0.96 | 10.9 | 15.2 | semi-rigid |
| S06 | y | 710 | 0.99 | 1.08 | 21.9 | 16.6 | semi-rigid |
| S07 | x | 610 | 0.86 | 1.64 | 17.9 | 25.2 | semi-rigid |
| S08 | y | 980 | 1.33 | 1.45 | 28.7 | 21.9 | semi-rigid |
| S10 | x | 610 | 0.86 | 1.64 | 17.9 | 50.4 | semi-rigid |

Diaphragm deflection is measured relative to the braced-frame (support) displacements. It is the largest of three measures:

* maximum displacement minus the average frame drift;
* displacement relative to the chord joining the two support lines;
* displacement relative to the line joining the average frame drifts of the two support lines.

Every case is below the 1.60 in limit of criteria 9.2. In every case the maximum diaphragm deflection is less than 2.0 x the average storey drift of the braced frames, so per criteria 9.3 the diaphragm is classified **semi-rigid**, as computed. Frame forces were therefore distributed by the stiffness model (inherent and accidental torsion included) and not by tributary width. For reference, the RC III allowable storey drift is 0.015 x 32 ft = 5.76 in.

Two stiffness effects drove the design:

* **Seismic y (S08):** it controls deflection and the peak shear, at the stiff east frames BF-Y3/BF-Y4 beside RO-3. This requires a strong, stiff east strip.
* **Collector (S10):** a uniformly stiff deck delivers the x-direction shear evenly along grid A. The stiff BF-X1/BF-X2 frames then pull about 30 kip into the grid A collector next to each frame, which is 60 kip after Omega0 and above the 58.0 kip splice. A deliberately softer deck strip in the middle of the south perimeter band moves delivery towards the braced bays and holds the amplified collector force below the splice capacity (LAT 6.2.1).

## 6. Zoning decisions

Zone rectangles lie on joist lines (6 ft in x) and sidelap lines (6 ft in y). Cells touched by a framed opening are left out of every zone; no deck is placed over openings, and temporary covers follow 29 CFR 1926.754(e)(3). Every zone touching the roof perimeter, or touching or diagonally adjacent to an opening, has at least 36/7 and 3 sidelap connectors per span (criteria 10.4). All zones have at least 2 sidelap connectors per span (36 in maximum spacing, criteria 10.3).

| Zone | Gage | Pattern | Sidelap | Rectangles (x0,y0,x1,y1 ft) | Area (sf) | Governing | Gravity D/C | Uplift D/C | Shear D/C |
|---|---|---|---|---|---|---|---|---|---|
| Z01 | 18 | 36/9 | SCREW-10 x 5 | (0,0,18,180); (210,0,240,180); (18,0,60,18); (180,0,210,18) | 9936 | S04 | 161/177 psf | 101.2/126.0 psf | 980/1226 plf |
| Z02 | 18 | 36/7 | SCREW-10 x 3 | (18,18,96,60); (96,18,108,48); (108,18,210,60); (18,60,180,84); (18,84,210,120); (18,120,132,132); (144,120,210,132); (18,132,210,168) | 27792 | S02 | 161/177 psf | 74.2/99.4 psf | 610/743 plf |
| Z03 | 22 | 36/9 | BP x 4 | (60,0,180,18); (18,168,210,180) | 4464 | S09 | 90/106 psf | 74.2/80.0 psf | 433/522 plf |

What drove each zone:

* **Z01 - 18 ga, 36/9, SCREW-10 x 5. West strip x 0-18 and east strip x 210-240 (full height), plus south-band end pieces x 18-60 and x 180-210 (y 0-18).**
  * Corner uplift of 101.2 psf: only 18 ga at 36/9 (126.0 psf) works, since 16 ga is unavailable.
  * The east strip carries the peak S08 shear (about 980 plf) where the stiff BF-Y3/BF-Y4 frames (68 kip/in) take the y force beside RO-3. Here phi Sn = 0.7 x 1751 = 1226 plf.
  * The strip also contains the SCR-E screen wall, with drifts up to 104.3 psf, and the SCR-N end drifts.
  * The stiff south-band end pieces flank the braced bays BF-X1 (x 30-60) and BF-X2 (x 180-210). They draw the x-direction shear into grid A near the frame columns, which keeps the collector force down.
  * SCREW-10 x 5 (G' = 45.6 kip/in) holds the S08 diaphragm deflection to about 1.3 in, against the 1.60 in limit.
* **Z02 - 18 ga, 36/7, SCREW-10 x 3. Core x 18-210, y 18-168, less the openings.**
  * Snow drifts govern: MEP-PH-1 east/west faces 104.3 psf and north/south faces 75.9 psf; SCR-N south face 89.5 psf; rooftop-unit windward drifts up to 98 psf; SCR-E west face 100.5 psf. Together these need 18 ga at many scattered cells.
  * The 14-rectangle limit makes separate 22 ga islands uneconomic. The enclosure interior would need four extra rectangles once the cell rule puts the face drifts into the cells along its inside edges.
  * The core borders all three framed openings, so criteria 10.4 sets the attachment at 36/7 with 3 sidelaps. That is also its uplift requirement in the zone 1/2 bands (99.4 psf against 74.2 psf). Rectangle boundaries are set by RO-1, RO-2 and RO-3.
* **Z03 - 22 ga, 36/9, BP x 4. South band middle x 60-180 (y 0-18) and north strip x 18-210 (y 168-180).**
  * Gravity is only balanced snow plus the 34.0 psf parapet drift, so 22 ga suffices.
  * Zone 2 uplift of 74.2 psf needs 36/9 on 22 ga (80.0 psf). This also meets the 10.4 perimeter minimum.
  * Button-punch sidelaps make this a deliberately soft strip (G' = 17.6 kip/in) between the stiff Z01 end pieces. It moves the x-direction seismic shear towards the BF-X1/BF-X2 columns, so the amplified collector force stays near 50 kip against the 58.0 kip splice capacity. With a uniformly stiff south band the collector reaches about 60 kip, which fails.
  * In the north strip the same specification is cheaper than SCREW-10, and it reduces the S08 chord force.

Installed cost at CP-RD-2026 rates, with areas net of opening cells:

| Item | Cost (USD) |
|---|---|
| Deck area | 180373 |
| Support fasteners (18008 ea) | 24311 |
| Sidelap connectors (8384 ea) | 8818 |
| Indirects | 20140 |
| **Total** | **233642** |

Zoning limits are met:

* 3 zones (12 maximum);
* 14 rectangles (14 maximum);
* 2 gages (2 maximum);
* 3 attachment patterns (3 maximum).

## 7. Coordination items

* **Deck end bearing (reported to the EOR per joist schedule note N1).**
  * Joist schedule note N2: the 26K9 top chord gives 2.5 in of bearing, shared by the two sheets that lap on the joist. If the two sheet ends simply split that width, each gets 1.25 in. That is below the 1.5 in minimum of N1, criteria 10.6, S-501 detail 1 and catalogue 7.4.
  * The deck schedule therefore requires sheet ends to be laid in 3-span lengths and to lap over the full chord width, as in S-501 detail 1, so that each panel end bears at least 1.5 in. No sheet end shall be butted on a joist.
  * Gravity reactions are far below catalogue Table 4-1 at 1.5 in bearing. The largest interior reaction, 1.1wL = 1.1 x 161 x 6 = 1062 lb/ft, compares with 2310 lb/ft for 18 ga. The largest 22 ga reaction, 593 lb/ft, compares with 1180 lb/ft.
  * The 0.1875 in top-chord leg meets the 0.125 in minimum support thickness of catalogue 7.4.
* **Deck lengths.** Deck shall run continuous over at least three spans. Where a zone or opening forces a shorter run, the single- or two-span capacity shall be confirmed.
* **Openings.** Deck is terminated and fastened on the L4x4x3/8 header angles at every opening.
