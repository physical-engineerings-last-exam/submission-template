# Change documentation for the Contracting Officer - Work Order 74213, Fleet Data Center Increment 2

Naval Support Activity Ventura Bay, California. Prepared by the Designer of Record (Calder Ridge Engineering) for the Contracting Officer, Code ACQ42. Both bid packages are covered; only BP-2 is issued as a change to a solicitation.

## BP-2 Central Utility Plant and Site Utilities - Solicitation N40085-26-R-2041 - Amendment 0003

- Change number: Amendment 0003 (third amendment to this solicitation, numbered in the four-digit form of the design procedures criteria).
- Continuation sheet file: 74213Amend0003.pdf. Attached drawing files (each a complete discipline set, bookmarked by discipline and by sheet): 74213Amend0003dwg1of3.pdf (C-101, E-001, E-101, E-501; 32.6 MB), 74213Amend0003dwg2of3.pdf (S-101, S-102, S-202, S-301, S-502; 38.3 MB), 74213Amend0003dwg3of3.pdf (M-101, M-301, M-401, M-501, M-502, M-503; 46.0 MB).
- Suggested SF 30 block 14 description (prepared by the Contracting Officer): EOR design review corrections to the drawings; 2 drawings added and 13 drawings replaced; no specification sections changed.
- Cost statement: the corrections are design-error corrections furnished by the Designer of Record; a construction cost estimate for the changed work accompanies the transmittal as the criteria require.

```
[CONTINUATION SHEET]

DRAWINGS:

                On NAVFAC Drawing No. 74213-GI001 (GI-001)
ADD the following drawings to the DRAWING INDEX, each in its own discipline and
drawing-number position. They are attached to Amendment 0003:
S-202  74213-S202  BRACED BAY FRAMING ELEVATIONS - ADDED SHEET
M-503  74213-M503  CHILLER PAD ANCHORAGE DETAILS - ADDED SHEET
REPLACE the following drawings in the DRAWING INDEX, each in its own discipline and
drawing-number position. Replacement sheets are attached to Amendment 0003:
C-101  74213-C101  SITE UTILITY PLAN - REPLACED SHEET
S-101  74213-S101  CUP FOUNDATION PLAN - REPLACED SHEET
S-102  74213-S102  CUP ROOF FRAMING PLAN - REPLACED SHEET
S-301  74213-S301  CUP BUILDING SECTIONS - REPLACED SHEET
S-502  74213-S502  FRAMING DETAILS - REPLACED SHEET
M-101  74213-M101  CUP CHILLED WATER PLAN - REPLACED SHEET
M-301  74213-M301  CHILLED WATER PLANT SECTIONS - REPLACED SHEET
M-401  74213-M401  CHILLER BAY ENLARGED PLAN - REPLACED SHEET
M-501  74213-M501  PIPING DETAILS - REPLACED SHEET
M-502  74213-M502  EQUIPMENT ANCHORAGE DETAILS - REPLACED SHEET
E-001  74213-E001  ELECTRICAL PANEL SCHEDULES - REPLACED SHEET
E-101  74213-E101  CUP POWER PLAN - REPLACED SHEET
E-501  74213-E501  ELECTRICAL DETAILS - REPLACED SHEET

Apart from the DRAWING INDEX entries above, every drawing change in this amendment is
made by an added or replacement sheet; each replaced sheet shows its changed areas
clouded, with revision indicator 3 and the matching revision block entry dated SEP 2026.

SPECIFICATIONS:

PROJECT TABLE OF CONTENTS
No specification section is added or replaced by Amendment 0003.

DOCUMENT 00 01 15 LIST OF DRAWINGS
1.2 Contract Drawings
ADD the following drawings, which are attached to Amendment 0003.
DRAWING NO. | REVISION NO. | NAVFAC DWG NO. | TITLE
S-202 | - | 74213-S202 | BRACED BAY FRAMING ELEVATIONS
M-503 | - | 74213-M503 | CHILLER PAD ANCHORAGE DETAILS
DELETE and REPLACE the following drawings as of SEP 2026; the replacement sheets are
attached to Amendment 0003.
DRAWING NO. | REVISION NO. | NAVFAC DWG NO. | TITLE
C-101 | 3 | 74213-C101 | SITE UTILITY PLAN
S-101 | 3 | 74213-S101 | CUP FOUNDATION PLAN
S-102 | 3 | 74213-S102 | CUP ROOF FRAMING PLAN
S-301 | 3 | 74213-S301 | CUP BUILDING SECTIONS
S-502 | 3 | 74213-S502 | FRAMING DETAILS
M-101 | 3 | 74213-M101 | CUP CHILLED WATER PLAN
M-301 | 3 | 74213-M301 | CHILLED WATER PLANT SECTIONS
M-401 | 3 | 74213-M401 | CHILLER BAY ENLARGED PLAN
M-501 | 3 | 74213-M501 | PIPING DETAILS
M-502 | 3 | 74213-M502 | EQUIPMENT ANCHORAGE DETAILS
E-001 | 3 | 74213-E001 | ELECTRICAL PANEL SCHEDULES
E-101 | 3 | 74213-E101 | CUP POWER PLAN
E-501 | 3 | 74213-E501 | ELECTRICAL DETAILS

                    -- End of Amendment 0003 --
```

Added sheets carry no revision number because they have no earlier issue; they are identified as ADDED SHEET in the drawing index and in the list of drawings above.

## BP-3 Data Hall 210 Shell and Interiors - Solicitation N40085-26-R-3018

No continuation sheet is submitted for BP-3. The EOR review corrections are incorporated in the design before the solicitation is advertised (pre-advertisement re-issue), so no change number is assigned, no revision entries are made and there is no change to a solicitation to document (paragraph 2 of the 26 August 2026 memorandum of the Contracting Officer). The corrected sheets are delivered as 74213dwg1of2.pdf (8 sheets, 45.7 MB) and 74213dwg2of2.pdf (8 sheets, 43.8 MB); the regenerated sheet index, from which the advertised drawing index is produced, lists the added sheets A-402 TELECOM ENTRANCE ROOM ENLARGED PLAN and M-502 CONTAINMENT WALL DUCT PENETRATION DETAILS. Advertisement stays on 9 November 2026.
