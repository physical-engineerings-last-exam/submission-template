# Design basis - EOR review corrections, Work Order 74213 (BP-2 and BP-3)

Prepared by the Designer of Record document controller, Calder Ridge Engineering, for Fleet Data Center Increment 2 at Naval Support Activity Ventura Bay. The program values below are the ones the submission files carry; the narrative explains how each was reached.

```json
{
 "packages": {
  "BP-2": {
   "issue_state": "AMENDMENT",
   "change_number": "0003",
   "overflow_option": 2,
   "revision_layers": [
    "G-ANNO-REVC",
    "G-ANNO-REVS"
   ],
   "n_bundles": 3,
   "production_days": 14,
   "delay_days": 1,
   "backcheck_window_days": 15,
   "ledger": {
    "bundles_usd": 14400,
    "sheets_usd": 18569.67,
    "added_sheets_usd": 12800,
    "revision_marks_usd": 3120,
    "overflow_option_usd": 1760,
    "non_concurrence_usd": 2400,
    "delay_usd": 2740,
    "total_usd": 55789.67
   },
   "title_block_defects": [
    {
     "sheet": "S-301",
     "defect": "CHK_EQUALS_DRW"
    },
    {
     "sheet": "E-501",
     "defect": "SEAL_DISCIPLINE_MISMATCH"
    }
   ]
  },
  "BP-3": {
   "issue_state": "PRE_ADVERTISEMENT_REISSUE",
   "change_number": "",
   "overflow_option": "NONE",
   "revision_layers": [],
   "n_bundles": 2,
   "production_days": 11,
   "delay_days": 0,
   "backcheck_window_days": 30,
   "ledger": {
    "bundles_usd": 9600,
    "sheets_usd": 20103.2,
    "added_sheets_usd": 12800,
    "revision_marks_usd": 0,
    "overflow_option_usd": 0,
    "non_concurrence_usd": 2400,
    "delay_usd": 0,
    "total_usd": 44903.2
   },
   "title_block_defects": [
    {
     "sheet": "A-501",
     "defect": "CHK_EQUALS_DES"
    },
    {
     "sheet": "M-101",
     "defect": "SEAL_DISCIPLINE_MISMATCH"
    }
   ]
  }
 },
 "governing_standards": [
  "FC 1-300-09N Navy and Marine Corps Design Procedures (edition dated 17 May 2024, with Change 1 dated 17 April 2025; NAVFAC preparing activity)",
  "ERDC/ITL SR-24-3 A/E/C Computer-Aided Design (CAD) Standard (Release 6.2, dated July 2024)",
  "ERDC/ITL SR-23-1 A/E/C Graphics Standard (Release 2.2, dated August 2023)",
  "ER 1165-2-217 Civil Works Review Policy (dated 1 May 2021; adopted by the 26 August 2026 memorandum of the Contracting Officer for the review comment, response, closure and location-statement conventions only)",
  "ERDC/ITL SR-21-6 Record Package Guidance: Best Practices (dated August 2021; adopted by the same memorandum for the markup colour convention only)",
  "ER 415-1-11 Biddability, Constructability, Operability, Environmental and Sustainability (BCOES) Reviews (dated 1 January 2013; the review regulation that fixes when the backcheck is conducted and when comments must be resolved)",
  "FAR 52.236-25 Requirements for Registration of Designers (JUN 2003), prescribed by FAR 36.609-4 (48 CFR Part 36)"
 ],
 "rejected_standards": [
  "ERDC/ITL TR-12-6 A/E/C CAD Standard (Release 6.0, dated August 2015) - superseded release; FC 1-300-09N paragraph 12-3.3.4 calls for the latest A/E/C version, which is Release 6.2",
  "UFC 1-300-09N Design Procedures (dated 25 May 2005, including Change 7 dated 27 January 2010) - cancelled; replaced by the current FC 1-300-09N",
  "GSA Public Buildings Service CAD Standards (owner legacy, dated March 2021) - another agency's standard for GSA deliverables; it does not govern a NAVFAC solicitation",
  "ER 1110-1-8159 DrChecks (dated 1 January 2015) - USACE administrative regulation for the DrChecks system; not adopted for this work order and sets no drawing, review-window or packaging requirement",
  "Fire protection comment log for BP-2 (separate A-E task order) - another task order and discipline, filed for coordination only and outside the BP-2/BP-3 drawing revision scope",
  "FY23 central utility plant record drawings (terminated solicitation N40085-23-R-2007) - reference record documents; their record layer set and revision history are not requirements for this issue"
 ],
 "rate_parameters": {
  "production_start": "2026-08-31",
  "sheets_per_day": 4,
  "days_per_bundle": 3
 },
 "void_markups": [
  {
   "comment_id": "EOR-2-015",
   "reason": "Author M. Delacroix is registered only in electrical engineering; the markup directs a change to mechanical plant section work outside that registered field, so it has no authority to direct the design change."
  },
  {
   "comment_id": "EOR-2-017",
   "reason": "Author G. Halvorsen is not on the reviewer roster for this design review and has no recorded registration, so the markup has no standing to direct a change."
  },
  {
   "comment_id": "EOR-2-019",
   "reason": "The markup annotation carries no creation date or time, so it cannot be traced to the review period or authenticated as a dated reviewer entry."
  },
  {
   "comment_id": "EOR-2-021",
   "reason": "The markup sits on the superseded 90 percent print of S-102, not on the issue out for bid; changes are made only against the current issue."
  },
  {
   "comment_id": "EOR-2-027",
   "reason": "Author K. Aoyama is the construction representative and holds no professional registration, so the markup cannot review, approve or direct a design change."
  },
  {
   "comment_id": "EOR-3-012",
   "reason": "The markup sits on the superseded 60 percent print of T-501, not on the certified issue; changes are made only against the current issue."
  },
  {
   "comment_id": "EOR-3-016",
   "reason": "Author M. Delacroix is registered only in electrical engineering; the markup directs a change to architectural wall work outside that registered field, so it has no authority to direct the design change."
  },
  {
   "comment_id": "EOR-3-018",
   "reason": "Author P. Okonjo is registered in civil engineering, and the markup directs a change to an architectural roof drain detail sealed by the architect, outside that registered field."
  },
  {
   "comment_id": "EOR-3-020",
   "reason": "The markup annotation carries no creation date or time, so it cannot be traced to the review period or authenticated as a dated reviewer entry."
  },
  {
   "comment_id": "EOR-3-022",
   "reason": "Author C. Ballantyne is not on the reviewer roster for this design review and has no recorded registration, so the markup has no standing to direct a change."
  }
 ]
}
```

## A. Documents that govern, and why

- NAVFAC is the construction agent, so FC 1-300-09N, in its current edition with Change 1, is the governing design procedures criteria. Its paragraph 12-3.3.4 sets the CAD order of precedence: the FC chapter itself first, then the latest A/E/C CAD and Graphics Standards, then the National CAD Standard. That clause is also why Release 6.2 of the A/E/C CAD Standard is applied and the Release 6.0 file in the folder is set aside.
- The 26 August 2026 memorandum of the Contracting Officer (its paragraph 7) adopts ER 1165-2-217 and ERDC/ITL SR-21-6 for the design-review conventions only (four-part comment, concur/non-concur response and closure, markup colours, statement of every affected location) and expressly brings in nothing else, in particular no record-package deliverable requirement.
- ER 415-1-11 is the review regulation the memorandum (paragraph 3) points to for when the backcheck is conducted and when comments must be resolved. FAR 52.236-25 (prescribed by FAR 36.609-4) and FC 1-300-09N paragraph 2-5 tie design review, approval and sealing to registration in the particular professional field.
- Dates: BP-2 was advertised 6 July 2026 with bid opening 28 September 2026 (solicitation schedule). BP-3 bid opening is 12 November 2026; its advertisement date is 9 November 2026 per memorandum paragraph 3, which controls over the 12 October 2026 date in the earlier schedule export.
- Rejected: A/E/C CAD Standard Release 6.0 (superseded), UFC 1-300-09N of 2005 (cancelled), GSA PBS CAD Standards (another agency), ER 1110-1-8159 (DrChecks administration, not adopted), the fire protection comment log (separate task order and discipline) and the FY23 record drawings (reference only).

## B. Which markups can direct a change

Every markup was read from the annotation objects on the sheets (author, timestamp, colour, note, sheet and drawing block) and checked against the reviewer roster and the review log. A markup cannot direct a design change on any of these grounds drawn from the corpus:

1. It was placed on a superseded submittal print rather than on the current issue (drawings README; SR-21-6 Chapter 2 places markups on the current working files): EOR-2-021 (90 percent S-102) and EOR-3-012 (60 percent T-501).
2. Its author is not on the reviewer roster, so the comment is not traceable to a member of the review team (ER 1165-2-217 paragraph 5.8.1): EOR-2-017 (G. Halvorsen) and EOR-3-022 (C. Ballantyne).
3. The annotation has no creation date, so it is not a dated reviewer entry (ER 1165-2-217 paragraph 4.7.1.5 requires checks to be initialed and dated): EOR-2-019 and EOR-3-020.
4. Its author is not registered in the professional field of the work the markup would change, or holds no registration at all, so it cannot review, approve or direct that design (FAR 52.236-25; FC 1-300-09N paragraph 2-5): EOR-2-015 and EOR-3-016 (M. Delacroix, electrical, on mechanical and architectural work), EOR-3-018 (P. Okonjo, civil, on an architectural roof drain detail) and EOR-2-027 (K. Aoyama, construction representative, no registration).

Each void markup is closed and recorded in the disposition register with its ground (CLOSURE VOID, RESPONSE NOT_APPLICABLE); nothing is incorporated from it and no non-concurrence charge arises. The yellow sticky notes reading CHECKED - NO COMMENT are not review comments and carry no comment number. The optional-content layer an annotation sits on is not a ground. EOR-2-033 and EOR-3-036 are valid markups but were closed as elevated for resolution in the 60 percent review and that closure was not reopened (review checklists; ER 1165-2-217 paragraph 5.9.1.2), so they are recorded as CLOSED_ELEVATED with no drawing action and no new non-concurrence.

## C. What each surviving comment does

All logged comments carry the four parts of ER 1165-2-217 paragraph 5.8.3. Green additions and red deletions that rest on criteria, the Design Analysis or a coordination or dimensional error are directive and are incorporated. Blue clarification markups whose basis is professional opinion or a drafting preference are not directive (ER 1165-2-217 paragraph 5.8.5; SR-21-6 Chapter 2 treats blue items as optional), so each was priced both ways: incorporation (re-issue, marked extent, revision mark and any sweep) against a documented non-concurrence ($2,400 plus one production day, which in BP-2 also lengthens the solicitation-extension exposure).

- BP-2: EOR-2-029 (E-101 already in the issue, only the marked extent is added), EOR-2-013 (E-001) and EOR-2-031 (M-301 view 2) are incorporated because each costs less than a non-concurrence. EOR-2-011 is non-concurred: it would re-plot C-501 and C-301 for a table relocation at about $2,957 against $2,400, with the same one-day schedule effect either way.
- BP-3: EOR-3-028 (A-201), EOR-3-032 (M-301) and EOR-3-034 (T-501) are incorporated. EOR-3-030 is non-concurred: it would re-plot S-301 and S-102 and push the delivered size past 100 MB, forcing a third bundle (about $7,325 in all).
- Every response follows the three-part form of ER 1165-2-217 paragraph 5.8.7 (concur or non-concur, the resolution, and every location changed or re-issued) and the justification rule of FC 1-300-09N paragraph 3-1.4.

## D. What an accepted change drags in

The reference graph was rebuilt from the callout bubbles on every current sheet. A bubble belongs to the drawing block it sits in, so a change to one block reaches only the blocks whose bubbles point at it; the sweep then repeats from each reached block until nothing new is found, across disciplines. For example, deleting the cast-in anchor in S-502 detail A (EOR-2-004) reaches E-501 A, M-501 A, M-502 A and view 2 of S-301 directly, then E-101, M-101, M-401 and S-102 through them; S-101 and S-201 are not reached because their bubbles point at view 1 of S-301. In BP-3, S-501 detail A (EOR-3-004) reaches A-501, E-501 and S-101, then A-101, A-301 and E-102. Only sheets that carry an incorporated markup, sheets added by a comment, and sheets reached by the sweep are re-plotted (rate schedule note 1). The drawing index sheet GI-001 contains no changed view and is not re-plotted: for BP-2 the added and replaced sheets are entered on the DRAWING INDEX by the continuation sheet, exactly as the sample of FC 1-300-09N Figure 18-1 does, and in DOCUMENT 00 01 15 (paragraph 18-5.1); for BP-3 the regenerated sheet index, from which the advertised drawing index is produced, carries the two added sheets.

- BP-2 re-issues 13 existing sheets (C-101, S-101, S-102, S-301, S-502, M-101, M-301, M-401, M-501, M-502, E-001, E-101, E-501) and adds 2 (S-202, M-503).
- BP-3 re-issues 14 existing sheets (S-101, S-501, A-001, A-101, A-102, A-201, A-301, A-501, A-502, M-101, M-301, E-102, E-501, T-501) and adds 2 (A-402, M-502).

## E. (a) Revision-graphics layers

The two shipped standards name different layers. The A/E/C CAD Standard (Release 6.2, paragraph 4.2.1 and its general layer table) lists "G-ANNO-REVC" for "Revision clouds" and "G-ANNO-REVS" for "Revision indicators and text". FC 1-300-09N paragraph 12-3.6.1 tells the drafter to put the cloud "on layer Z-ANNO-REVC" and the revision symbols on the Z-ANNO-REVS layer. The clause that fixes the order of precedence is FC 1-300-09N paragraph 12-3.3.4, which ranks first "the requirements of this Chapter", second the newest A/E/C CAD and Graphics Standards, and the NCS last. Applying that order, an FC chapter 12 rule governs wherever it applies; but the Z-ANNO rule sits under Record Drawing Preparation and is written for record drawings prepared after construction, the 26 August 2026 memorandum (its paragraph 7) confirms that no record-package deliverable requirement applies to this work order, and the FY23 record prints carry the Z set precisely because they are record documents. FC chapter 12 therefore sets no revision layer for a pre-award amendment of the contract drawings, and the next authority in the order, A/E/C CAD Standard Release 6.2, governs. Layers actually used for the BP-2 Amendment 0003 graphics: G-ANNO-REVC for the revision clouds and G-ANNO-REVS for the revision triangles and the Revision (Issue) block entries, the same layers that already carry the Amendment 0001 and 0002 entries on the current sheets. BP-3 carries no revision graphics, so no revision layer is used there.

## F. (b) BP-3 issue state, dates and review window

BP-3 is certified and not yet advertised: advertisement 9 November 2026 (memorandum paragraph 3, controlling over the 12 October 2026 export date) and bid opening 12 November 2026, only three days later. ER 415-1-11 paragraph 6 gives two durations. Its BCOES backcheck subparagraph (g) says the backcheck “should be started 30 calendar days prior to advertising” and that “all comments shall be resolved prior to bid opening”; its scheduling subparagraph (e) allows “about 15 calendar days” for back checking of comments. Decision: PRE_ADVERTISEMENT_REISSUE, applying the 30-calendar-day window. When corrections are incorporated before advertisement the binding requirement is that the backcheck can start 30 days before the advertisement date, so the corrected sheets must be finished by 2026-10-10. Production starts 2026-08-31 and takes 11 days (4 for 16 sheets at 4 per day, 6 for 2 bundles, 1 for one non-concurrence), finishing 2026-09-11, so neither the advertisement nor the bid opening moves (D = 0, no extension charge). The 15-day backcheck window is the one that binds the other course, an amendment issued during the advertisement period, because only the resolution-before-bid-opening limit applies once the package is advertised; that course cannot work here: an amendment cannot issue before 9 November, and 15 days of backcheck after it would move bid opening from 12 November to at least 24 November (12 days, $51,360 at 2,600 x D + 140 x D squared), on top of revision marks and overflow work on full blocks. Pre-advertisement re-issue also needs no change number, no continuation sheet and no revision entries (memorandum paragraph 2). The DOR therefore recommends course (a) of memorandum paragraph 3, without any hold of the 9 November advertisement.

## G. BP-2 amendment, window and schedule

BP-2 is already advertised, so a change to the solicitation is the only lawful course: changes before award are amendments (FC 1-300-09N paragraph 18-1; A/E/C Graphics Standard paragraph 7.1). Two amendments have been issued, so this is Amendment 0003 in the four-digit form of FC 1-300-09N paragraph 18-3 (memorandum paragraph 1). The 30-day before-advertising window cannot apply after advertisement; the binding window is the 15 calendar days of backcheck that must be complete before the 28 September 2026 bid opening (ER 415-1-11 paragraph 6, subparagraphs (g) and (e)), giving a production deadline of 2026-09-13. Production: 4 days for 15 sheets, 9 days for 3 bundles (116.9 MB cannot fit in two 50 MB files) and 1 day for one non-concurrence, 14 days in all, finishing 2026-09-14 (finish taken as production start plus production days). D = 1 day, extension charge $2,740. No plan does better: three bundles are unavoidable, and incorporating EOR-2-011 instead of non-concurring it raises the sheet count to 17 and still takes 14 days.

## H. (c) BP-2 Revision (Issue) block overflow

Row capacity: the Revision (Issue) block “provides eight rows for identifying revisions” (A/E/C Graphics Standard paragraph 7.3). Six BP-2 sheets in this issue already have all eight rows filled (M-101, S-102, C-101, M-501, S-502, S-101), so the new entry 3 cannot be placed in the block as drawn. The standard offers Option 1 (replace the oldest entry and keep displaced entries outside the plotted area, Figure 7-3) and Option 2 (continue above the eighth row into the drawing area, Figure 7-4), and states that the chosen option “shall remain consistent across the entire drawing set”. Option 2 is taken and applied set-wide to every BP-2 sheet, not chosen sheet by sheet; on the six full sheets entry 3 is placed in the first row above the block (row position 9). Cost reason: Option 1 is charged $520 on each of the six full sheets ($3,120), whereas Option 2 is charged $880 only where the spill area is occupied, i.e. on full sheets with three or more drawing blocks (M-501, S-502: $1,760); the single-block sheets C-101, S-101, S-102 and M-101 have a free spill area at no charge. Option 1, although labelled preferred, is rejected because it costs $1,360 more.

## I. Identification and graphics

- Revision marks (BP-2): each replaced sheet gets the next sequential amendment number, 3, in an equilateral triangle beside a 0.35 mm revision cloud (A/E/C Graphics Standard paragraph 7.2; FC 1-300-09N paragraph 18-5.1). The block entry is placed above the previous one, uses the same brief description on every sheet, EOR DESIGN REVIEW CORRECTIONS - SEE CONTINUATION SHEET, without listing the amendment number (FC 1-300-09N paragraph 18-5.1), and is dated SEP 2026 in the MMM YYYY form of A/E/C Graphics Standard paragraph 7.3. Sheet numbers of revised drawings are not changed.
- Added sheets take the next free sequence number in the sheet-type series that matches their content (A/E/C CAD Standard paragraphs 2.4.4 and 2.4.4.2, Table 2-4): S-202 elevations, M-503 details (BP-2); A-402 large-scale view and M-502 details (BP-3). No supplemental letter is needed because no sheet is inserted between two consecutively numbered sheets (paragraph 2.4.4.1), and the record-drawing practice of suffix letters does not apply. Callout-to-sheet-type coupling (A/E/C Graphics Standard paragraphs 4.2.4.2 and 4.2.4.4): the new elevation bubbles on S-101 point to a type 2 sheet, the new detail bubbles on M-401 and M-101 to type 5 sheets and the enlarged-plan bubble on A-101 to a type 4 sheet. NAVFAC drawing numbers follow the project pattern (74213-S202 and so on) and are confirmed with the Design Manager (FC 1-300-09N paragraph 7-4); added sheets are plotted at the 5.5 MB allowance of the rate schedule.
- Index ordering: disciplines follow Table 2-3 of the A/E/C CAD Standard (G-, GI, C-, S-, A-, M-, E-, T-), and within each discipline the general notes, abbreviations and legend sheets come first (paragraph 2.4.4.2 of Release 6.2; Release 6.0 had no such exception). So GI-002 precedes GI-001, M-003 precedes M-001, E-004 precedes E-001 and A-002 precedes A-001. The export SORT_ORDER is only the tool default (index README).
- BP-3 is re-issued before advertisement, so its sheets carry no clouds, triangles or block entries; the revision log records that no entry is made for each re-issued sheet and existing marks are unchanged.

## J. Title blocks of the re-issued sheets

Checked against FC 1-300-09N paragraph 12-4.1 (typed DES, DRW and CHK initials, with the checker different from both designer and drafter, and a seal for the discipline responsible for the sheet) and paragraph 2-5 with FAR 52.236-25. Non-compliant sheets in this issue: BP-2 S-301 (checker RCM is also the drafter) and E-501 (electrical details under a mechanical seal); BP-3 A-501 (checker HGB is also the designer) and M-101 (mechanical CRAH plan under an electrical seal). These are corrected on the re-issued sheets before signature. C-102 (BP-2) and T-101 (BP-3) also show checker conflicts but are not in this issue. The general sheets carry the architect of record seal for coordination of the set and are not reported.

## K. Packaging and cost ledger

Bundles keep whole discipline sets together and stay within 50 MB and 50 sheets per PDF (FC 1-300-09N paragraphs 12-3.5.1 and 12-3.5.2.1), using the production plot sizes of the index exports. BP-2 files are named with the amendment number (paragraph 12-3.5.6: 74213Amend0003dwg1of3.pdf to 3of3, continuation sheet 74213Amend0003.pdf); BP-3 files use the final design form with a multi-file suffix (paragraph 12-3.5.5: 74213dwg1of2.pdf, 74213dwg2of2.pdf).

- BP-2: bundles 3 x $4,800 = $14,400; sheets 13 x $1,150 plus 139.218 sq in of incorporated markup x $26 = $18,569.67; added sheets 2 x $6,400 = $12,800; revision marks $3,120; overflow $1,760; non-concurrence 1 x $2,400 = $2,400; extension $2,740; total $55,789.67.
- BP-3: bundles 2 x $4,800 = $9,600; sheets 14 x $1,150 plus 153.969 sq in of incorporated markup x $26 = $20,103.20; added sheets 2 x $6,400 = $12,800; revision marks $0; overflow $0; non-concurrence 1 x $2,400 = $2,400; extension $0; total $44,903.20.

Markup extents are the annotation rectangles of the incorporated markups converted at 72 points per inch. The sheet line covers the per-sheet re-issue charge and the markup-extent charge; added sheets are charged only on the added-sheet line. Combined cost of issuing the corrections: $100,692.87.
