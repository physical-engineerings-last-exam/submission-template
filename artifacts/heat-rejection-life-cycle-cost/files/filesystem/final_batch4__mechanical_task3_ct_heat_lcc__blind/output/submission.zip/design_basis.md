# Design basis - condenser water heat rejection replacement, Papago Federal Center (95 % CD)

Prepared by the mechanical EOR plant designer under DC-02 Revision 3 and EC-01 Revision 0.

## 1. Governing documents

* DC-02 Mechanical Design Criteria Memorandum, Revision 3 (14 Aug 2026) - criteria, conventions, deliverable formats (Appendix A).
* UFC 3-410-01 (28 July 2025, Change 1) - outdoor design condition for tower sizing (paragraph 2-4.2.4: 1.0 % wet bulb + 5 F); Section 908 amendment (automatic blowdown and chemical feed).
* PBS P100 2024 (GSA Facilities Standards) - cooling robustness (5.1.3), cooling towers (5.3.2.3), galvanized steel prohibition (5.3.3.11), intake separation (Table 5.2).
* UFM 3-230-13 (5 February 2026) and WT-01 Revision 1 - water balance, cycles of concentration, silica and Practical Scaling Index limits.
* PW-LTR-014 and PW-LTR-019 Amendment 1 (ANNEX annual allocation 12,600 kgal/yr), UT-01 (rate GS-L, 100 % ratchet).
* E-601 Revision C with RFI-034 (MCC-R3 reduced by the three 7.5 hp lab exhaust fans), E-501 Revision C.
* M-401 Revision C (equipment zones, outdoor air intakes), S-401 Revision C (framing zones and allowable superimposed loads), M-601 Revision C, M-603.
* Submittals VD-01 to VD-05, specification 23 65 00, 10 CFR 431.25 (motor efficiency), 10 CFR 436 Subpart A with EC-01, the 2025 Annual Supplement data release (doi:10.18434/mds2-3848).
* Simulation basis: EnergyPlus CondenserLoopTowers.cc, ChillerElectricEIR.cc, Psychrometrics.cc/.hh, CurveManager.cc, Chillers.idf and PerfCurves.idf (CoolingTowerPerformance:YorkCalc "YorkCalc Default Tower Model", the counterflow object that carries the liquid-to-gas limit DC-02 6.8 tests).
* Retained for reference only and not used as authority: UFC 3-230-13 (1 March 2023, superseded by UFM 3-230-13), UFC 3-400-02 (cancelled), NIST IR 85-3273-39 (2024 supplement, superseded by the 2025 data release), M-401 Revision B (superseded), DC-02 Revision 2, the Tucson station record, specification excerpt 23 25 00 (closed systems only).

## 2. Documented conflicts (DC-02 9.1)

CONFLICT 1: ADOPTED UFC 3-410-01 paragraph 2-4.2.4 | SET ASIDE PBS P100 paragraph 5.3.1
CONFLICT 2: ADOPTED UFM 3-230-13 (5 February 2026 edition) paragraph 1-2 | SET ASIDE UFC 3-230-13 (1 March 2023 edition) in full
CONFLICT 3: ADOPTED M-401 Rev C (Revision C) | SET ASIDE M-401 Rev B (Revision B)

Resolution notes: (1) DC-02 paragraph 2 allocates outdoor design conditions for equipment sizing to UFC 3-410-01, so tower selection uses the 1.0 % annual wet bulb + 5 F of 2-4.2.4 and not the P100 5.3.1 0.4 % dew-point basis; the P100 wet-bulb basis is still applied, as RFI-031 directs, to the cooling robustness (largest cell out) calculation of P100 5.1.3. (2) UFM 3-230-13 paragraph 1-2 supersedes UFC 3-230-13 (DC-02 paragraph 2, RFI-031 Response 3). (3) M-401 Revision C governs the equipment zones and intake positions; Revision B is superseded (RFI-031 Response 3, specification 23 65 00 paragraph 3.1).
Other library disagreements resolved: PBS P100 5.3.5.3 TDS cap does not govern the reclaimed supply (DC-02 paragraph 2); PW-LTR-019 amends the ANNEX allocation to 12,600 kgal/yr; RFI-034 reduces the MCC-R3 spare capacity to 641.14 kW; the UFM Table A-7 value (7.59) and the appendix closed form (1.485 log TA + 4.54 = 7.628) differ - WT-01 4.1 directs the closed form, which is used.

## 3. Climatic and property basis

* POR: NCEI LCD Phoenix airport (72278023183) 2022, 2023, 2024, FM-15 and FM-16 rows only (summary rows excluded; Tucson excluded). Values flagged "s" (suspect) are used at their numeric value; observations without a reported wet bulb (mostly December 2024, missing station pressure) cannot be binned and are excluded. 26,527 observations carry both dry and wet bulb.
* Weather basis applied: tower selection, design point, scheduled design approach and redundancy capacity check are sized on the 1.0 % annual wet bulb = 75 F plus the 5 F adder of UFC 3-410-01 paragraph 2-4.2.4 -> design wet bulb 80.0 F (DC-02 5.2, RFI-031 Response 1). The failure-case (largest cell out) calculation uses the 0.4 % evaporation design wet bulb that PBS P100 5.1.3 names, 76 F, with the same adder -> 81.0 F. The YorkCalc object clamps inlet wet bulb at 26.6667 C (80.0 F) per DC-02 6.8.
* 99.6 % annual dry bulb from the POR = 41 F, above 32 F: no basin heater and no heat-traced makeup are required (DC-02 5.4); BASINHEATER NO on all plants.
* Barometric pressure = POR mean station pressure 28.722 inHg = 97,264 Pa (DC-02 5.5). Q (BTU/h) = 500 x gpm x range.
* Scenario bins per DC-02 5.3: 2 F wet bulb x 5 F dry bulb bins from 0 F (lower edge inclusive), mid-points, dry bulb raised to the wet-bulb mid-point where lower, counts scaled to 8,760 h -> 180 bins. Block load = M-603 linear interpolation at bin dry bulb, end values held.

## 4. Calculation methods

* Chillers: EnergyPlus Chiller:Electric:EIR model with the M-601/VD-03 data sets (CAPFT and EIRFT at leaving chilled water and entering condenser water, EIRFPLR, minimum PLR cycling, false loading, inputs clamped to curve limits). Staging per DC-02 6.5 with available capacity = reference capacity x CAPFT at the operating ECWT; load shared equally. Condenser heat = evaporator load + compressor power.
* Tower: YorkCalc variable-speed approach correlation (PerfCurves.idf object coefficients), WFRR = cell flow / VD-01 nominal flow, L/G = WFRR / AFR. Control per DC-02 6.7 and calculateVariableSpeedTower: full speed when the setpoint cannot be met (supply floats to the full-speed equilibrium), modulation to the setpoint (fan power = AFR^3), minimum speed 0.3 with cycling, free convection at AFR 0.125 with fans off; bypass holds supply at the setpoint. Cell staging per DC-02 6.6 (effective minimum = max(VD-01 minimum, 0.75 x nominal)).
* Fan electrical input = design bhp x 0.7457 / (premium motor efficiency x VFD efficiency 0.97) per cell at full speed (VD-02). Pump input per DC-02 6.4, one constant-speed pump per running chiller.
* Design point (DC-02 6.9): all chillers, scheduled design flow, all cells at full speed, design wet bulb 80 F, design block load; the DesignPoint sheet reports what the selected cells achieve; CWSDESIGN on the schedule is a conservative rounding up. Redundancy (DC-02 6.3): one cell out, remaining cells at full speed, design flow, failure-case wet bulb 81 F (clamped in the correlation); RedundancyCapacity = chillers x reference capacity x CAPFT at the resulting ECWT.
* Evaporation formulation used: SATURATED-EXIT (moist-air method of calculateWaterUsage, inlet enthalpy saturated at the inlet wet bulb, outlet saturated at inlet enthalpy + Q / air mass flow, water density by the DC-02 7 formula at the mean of inlet dry bulb and saturated outlet temperature, not below 4 C), for all three plants, both for the water balance and the allocation checks, and therefore consistent with the EC-01 priced quantities. Drift = design flow x (cells on / cells) x certified drift fraction x AFR; blowdown = E/(COC-1) - drift; makeup = E + drift + blowdown. Peak day: 24 h at 80 F wet bulb, 112 F dry bulb, design block load, controlled as scheduled (PW-LTR-014 2).
* Water chemistry: analysis of record 2022-07-26 (most recent complete analysis): dissolved Ca 109 mg/L -> 272.2 ppm CaCO3, TDS 1,720 mg/L (residue on evaporation), dissolved silica 16.0 mg/L; acid feed holds M-alkalinity at 120 ppm. Silica limit 150/16.0 = 9.38 cycles; PSI = 2 pHs - pHeq with pHs = 9.3 + A + B - (C + D), A, C, D closed forms of WT-01 4.1, B from UFM Table A-2 by linear interpolation at the design-point CWR actually produced, pHeq = 1.485 log(120) + 4.54. The PSI >= 5.60 limit governs; COC is scheduled at the allowable value rounded down to two decimals.
* Life-cycle cost (EC-01, 10 CFR 436): base date 1 Oct 2025, constant dollars, DOE real discount rate 3.0 percent, study period 26 yr (1 yr construction + 25 yr service life of the longest-lived admissible alternative, stainless steel; galvanized G-235 is not admissible under P100 5.3.3.11). Investment per VD-05 (base, material fraction, eliminator, premium motor, rigging 0.85 USD/lb, connections 14,000 per cell, plant controls 60,000) at the base date. Energy: annual kWh x 0.0712 + peak coincident demand x 17.80 x 12; UPV* = 16.3061 - 0.9709 = 15.3352 (UPV - DOE table, West/Mountain/Commercial/Electricity). Water and sewer at saturated-exit makeup and blowdown, 1.94 and 3.20 USD/kgal, real escalation 1.035/1.015 - 1 = 1.970 percent/yr, UPV* = 21.7770. Treatment 0.42 USD/kgal makeup and maintenance per cell per year at UPV = 17.8768 - 0.9709 = 16.9060. Stainless cells have a 25-yr life equal to the service period: no replacement and no salvage. Basic design per EC-01 5, simulated on the same basis.

## 5. Selected designs

* CUP: 4 x CTX-0600-S, GPMTOTAL 1801 gpm (450.25 gpm per cell), premium 6-pole TEFC motor, DE-2 eliminator (0.002 %), SS-304, reset floor 65.5 F / offset 11.5 F, COC 4.14 (max allowable 4.143 at design CWR 98.02 F), CWSDESIGN 86.0 F (achieved 85.36 F), design range 12.65 F, redundancy 918 t at 87.86 F ECWT, peak demand 515.1 kW, annual makeup 9565 kgal (saturated-exit), peak day makeup 49038 gal and blowdown 11816 gal, investment 786,200 USD, LCC 5,645,854 USD, basic design LCC 5,891,408 USD, net savings 245,554 USD.
* ANNEX: 4 x CTX-0600-S, GPMTOTAL 1801 gpm (450.25 gpm per cell), premium 6-pole TEFC motor, DE-2 eliminator (0.002 %), SS-304, reset floor 79.5 F / offset 11.5 F, COC 4.0 (max allowable 4.002 at design CWR 99.37 F), CWSDESIGN 86.5 F (achieved 85.70 F), design range 13.68 F, redundancy 946 t at 88.34 F ECWT, peak demand 570.8 kW, annual makeup 12578 kgal (saturated-exit), peak day makeup 52976 gal and blowdown 13214 gal, investment 786,200 USD, LCC 7,640,062 USD, basic design LCC 7,900,807 USD, net savings 260,745 USD.
* LAB: 3 x CTX-0900-H, GPMTOTAL 2028 gpm (676.0 gpm per cell), premium 6-pole TEFC motor, DE-2 eliminator (0.002 %), SS-304, reset floor 57.5 F / offset 8.75 F, COC 3.88 (max allowable 3.881 at design CWR 100.57 F), CWSDESIGN 86.5 F (achieved 85.99 F), design range 14.58 F, redundancy 1234 t at 90.19 F ECWT, peak demand 634.2 kW, annual makeup 16943 kgal (saturated-exit), peak day makeup 73494 gal and blowdown 18898 gal, investment 926,220 USD, LCC 7,768,211 USD, basic design LCC 8,064,175 USD, net savings 295,963 USD.

## 6. Governing constraint per plant (DC-02 9)

GOVERNING CONSTRAINT CUP: electrical capacity (relative margin 0.0244)
GOVERNING CONSTRAINT ANNEX: water allocation (relative margin 0.0017)
GOVERNING CONSTRAINT LAB: electrical capacity (relative margin 0.0109)

* CUP margins: water allocation 0.0714; electrical capacity 0.0244; roof area 0.4889; structural capacity 0.0250; condenser flow limit 0.2007; tower capability 0.1062
* ANNEX margins: water allocation 0.0017; electrical capacity 0.0326; roof area 0.4889; structural capacity 0.0565; condenser flow limit 0.2007; tower capability 0.1236
* LAB margins: water allocation 0.0262; electrical capacity 0.0109; roof area 0.3972; structural capacity 0.0162; condenser flow limit 0.2707; tower capability 0.0782

Margin definitions follow the DC-02 9 table: water allocation from the reported annual makeup, electrical capacity from the reported peak coincident demand, structural from operating weight / support frame area against the S-401 zone each frame bears on, condenser flow limit over the four VD-03/VD-01 equipment limits at the scheduled flows, tower capability from the scheduled approach against the achieved design approach, roof area with each cell charged its frame plus one air-inlet clearance in each plan direction.

## 7. Judgement calls and margins

* Layout: only CTX-0600-S and CTX-0900-S fit four cells in the CUP and ANNEX zones with VD-01 clearances and one-framing-zone supports; two-cell plants cannot satisfy the redundancy flow limit (one remaining cell would exceed 120 % of nominal). LAB zone fits at most four CTX-0900-S or three CTX-0900-H cells inside framing zone LAB-S1 (LAB-S2 strip is too narrow), so a six-cell plant is impossible and three cells (one per chiller) are used; three CTX-0600 cells would need less than the 532 gpm machine minimum; CTX-0900-S cannot hold the MCC-R3 limit, so CTX-0900-H is selected.
* Flow: design flows sit just above the 0.75 WFRR / effective-minimum cell flow with all cells in service (pump energy dominates); with one chiller running two cells stay in service above the effective minimum.
* Reset schedule optimised for net savings: large offsets keep the fans slow (fan energy and saturated-exit evaporation fall faster than chiller energy rises).
* Electrical and water margins: the schedules hold peak demand and annual makeup a small margin inside the MCC spare and allocation; BASINCLR 4.5 ft (P100 minimum 4 ft); all cell frames at least 25 ft from the M-401 Rev C intakes (P100 Table 5.2) - actual minimum 39 ft (CUP), 40 ft (ANNEX), 43 ft (LAB); every frame at least 7 ft inside the equipment zone and 7 ft from adjacent frames (VD-01 clearance 6 ft).
* Material SS-304: lowest LCC admissible option (FRP-PV is cheaper first but its 20-yr life forces a year-21 replacement; SS-316 costs more for the same life). Drift eliminator DE-2: lowest-cost class meeting 23 65 00 2.3. Premium motors: the economy motors fall below 10 CFR 431.25 Table 5.
