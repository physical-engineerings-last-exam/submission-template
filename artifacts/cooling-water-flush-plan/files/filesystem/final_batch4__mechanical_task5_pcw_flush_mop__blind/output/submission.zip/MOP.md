# Method of Procedure - PCW Cleaning, Flushing, Passivation and Turnover
Tull Creek Data Hall - Process Cooling Water (PCW) loop, circuits C1-C8. Prepared by the flushing contractor commissioning engineer under Section 23 25 16 Rev 3 cl.1.6.

All times are hours from mobilisation (TM-0 = hour 0). Calendar day k = hours [24k, 24k+24); crew shift k = hours [12k, 12k+12).

## 0. Summary of the plan
- Circuits from the Rev C P&IDs; hydrostatic tests owed only on C3, C5, C6, C7 (charts TR-0414/0416/0417/0418 missing), at 127.5 psig for 120 min before TM-1.
- Flushing flows from the greater of 3.28 ft/s (UFC para 5-3.7) and the 4.0/2.0 ft/s project class in every leg: C1 1,185 gpm on FS-1200-A; C2/C3 625/722 gpm on FS-1200-A (C2 rinse on FS-600-A+B in parallel); C4-C8 on FS-600 units. All duty points inside the published curves and the SW-04 panel limits.
- CL-100 on C1-C5 and C7, CL-210 on C6 (aluminium) and C8 (galvanized), with 5 ppm PD-45, 24 h circulation; molybdate-azole programme on C1-C5 and C7, polysilicate-azole on C6 and C8 (nitrite excluded: Cl + SO4 = 860 mg/L > 800).
- Rinse counts from the 23 25 16 cl.3.6 model to 676.5 microS/cm: 6 displacements (C1, C2, C3, C8), 8 (C4-C7); full cascade chain C1 > C5 > C3 > C4 > C8 > C2 > C6 > C7 keeps the MH-14 total at 496,284 gal under the SW-03 Rev B 500,000 gal cap; spent cleaner of the copper/zinc circuits C4-C8 hauled.
- Passivation per Tables 5-14/5-15 with a 14-day (336 h) hold; RETAIN_AND_TOP_UP turnover with softened (SV-2) makeup on three fill days; all work complete by hour 721 (TM-4 = hour 1128).
- Programme cost $48,808.25 (23 25 16 cl.3.10); governing constraint for every circuit: authorised programme discharge volume, margin 0.00743.

## 1. Scope
Pre-operational hydrostatic testing (where owed), initial flush, alkaline/neutral chemical cleaning with dispersant, rinse to the UFC 3-230-13 acceptance criterion (with cascaded displacements), passivation, 14-day film-formation hold and turnover fill with the closed-system maintenance programme, for the eight tie-in-bounded PCW circuits. Domestic water (22 11 23) and the comfort-cooling chiller (VD-08) are outside this scope.

## 2. Document basis
Applied (governing): Section 23 25 16 Rev 3; Section 23 21 16 Rev 3; Section 01 91 13 Rev 2; UFC 3-230-13 (1 March 2023, current edition); DOE-HDBK-1012/3-92; 40 CFR 403; 29 CFR 1910.1200; M-PID-101/102/103/104 Rev C; M-ISO-201..204 Rev C; M-601/602/603 Rev C; E-701 Rev B; C-101 Rev B; SW-01; SW-02; SW-03 Rev B; SW-04 Rev B; SI-04; SI-05; RFI-022; RFI-031 (tanker rate and route only); CX-01 Rev B; CX-02 with charts TR-0412, TR-0413, TR-0415, TR-0419; CX-03; VD-01 to VD-07.

Read and rejected (not used as authority anywhere in the plan or register):
- UFC 3-240-13FN (2005) - cancelled; 23 25 16 cl.1.2 forbids its use. Its Tables 4-14/4-15 carry the same passivation values as the current Tables 5-14/5-15, but only the 2023 edition is cited.
- M-PID-103 Rev A - superseded by Rev C (M-601 Note 5). Rev A shows line 4033 (x2) in circuit C4; Rev C places 4033 (x3) in C5. Rev C used.
- SW-03 original issue (Rev A) volume of 540,000 gal and the same figure repeated in RFI-031 - superseded by SW-03 Rev B s.2 (500,000 gal). Rev A local limits remain in force through Rev B s.3 and are cited as such.
- 40 CFR 122 (NPDES) - not adopted; the discharge is to the POTW under a pretreatment authorisation (SW-03 general condition 2), not to surface water.
- Section 22 11 23 (domestic water pumps), VD-08 (air-cooled chiller), RFI-009 (roof flashing) - not PCW scope.
- UFC 3-230-13 open-cooling-tower provisions (e.g. Table 5-11 film formation 10-12 days) - not applied except where 23 25 16 invokes them (para 5-3.7 velocity and dispersant, para 5-7.3.2.2 circulation and rinse criterion, Tables 5-14/5-15 passivation).
- NB-700 nitrite-borax-azole (VD-06) - quoted for comparison only; excluded by makeup chloride + sulfate (para 6-2.2.2).

## 3. Circuit definition (read from the P&IDs, Rev C)
| Circuit | Tie-ins / location | Lines (legs) | Components (bypass) | Metallurgy | Static lift ft |
|---|---|---|---|---|---|
| C1 | TI-C1-01/02, MER-1 | 1041, 1042, 1043 (x4), 1044 (x4) | PMP-101 (in path), BT-101 (in path) | carbon steel | 26 |
| C2 | TI-C2-01/02, MER-1 | 2011, 2012, 2013 (x3) | HX-201A (bypassed) | carbon steel, stainless/nitrile PHE | 22 |
| C3 | TI-C3-01/02, MER-2 | 2021, 2022, 2023 (x2) | HX-201B (bypassed) | carbon steel, stainless/nitrile PHE | 22 |
| C4 | TI-C4-01/02, L3-N | 4021, 4022, 4023 (x2), 4024 (x4) | CDU-301 (bypassed), CP-311 (bypassed) | carbon steel, copper, SS/Cu CDU, Cu cold plates | 48 |
| C5 | TI-C5-01/02, L3-S | 4031, 4032, 4033 (x3), 4034 (x4) | CDU-302 (bypassed), CP-321 (bypassed) | carbon steel, copper, SS/Cu CDU, Cu cold plates | 44 |
| C6 | TI-C6-01/02, L3-W | 4041, 4042, 4043 (x3) | CP-331 (bypassed) | carbon steel, copper, ALUMINIUM cold plates | 48 |
| C7 | TI-C7-01/02, ROOF | 5011, 5012, 5013 (x4) | CL-401 (bypassed) | carbon steel, copper (coil fins dry side only, VD-04 note 4) | 72 |
| C8 | TI-C8-01/02, YARD | 6011, 6012, 6013 (x2) | ST-601 (in path) | hot-dip galvanized (RFI-022) | 14 |

## 4. Design basis
### 4.1 Volumes, flushing flow and governing segment
FLUSH volume V_f = pipework (M-601 ID, length per leg x legs) + hold-up of components left in the path; SYSTEM volume V_s = pipework + every component (M-602). Flushing velocity per 23 25 16 cl.3.3 = greater of UFC 3-230-13 para 5-3.7 (3.28 ft/s) and the project class minimum (4.0 ft/s where the circuit serves a PHE or cold-plate device, else 2.0 ft/s), in every leg (parallel legs share equally).

| Circuit | V_f gal | V_s gal | v_min ft/s | Q_req gpm | Q declared gpm | Governing segment (ID in) | v at Q ft/s | Re |
|---|---|---|---|---|---|---|---|---|
| C1 | 32,983.4 | 32,983.4 | 3.28 | 1,181.42 | 1185 | 1043 (6.065) | 3.290 | 153,962 |
| C2 | 5,596.0 | 7,946.0 | 4.00 | 623.71 | 625 | 2011 (7.981) | 4.008 | 246,835 |
| C3 | 6,203.2 | 8,553.2 | 4.00 | 720.38 | 722 | 2023 (6.065) | 4.009 | 187,612 |
| C4 | 5,956.6 | 8,536.6 | 4.00 | 360.19 | 362 | 4021 (6.065) | 4.020 | 188,132 |
| C5 | 6,405.8 | 8,985.8 | 4.00 | 476.14 | 477 | 4033 (4.026) | 4.007 | 124,482 |
| C6 | 4,227.1 | 5,677.1 | 4.00 | 360.19 | 362 | 4041 (6.065) | 4.020 | 188,132 |
| C7 | 4,086.0 | 6,036.0 | 3.28 | 295.36 | 297 | 5011 (6.065) | 3.298 | 154,351 |
| C8 | 5,790.8 | 5,790.8 | 3.28 | 151.16 | 152 | 6013 (3.068) | 3.298 | 78,081 |

### 4.2 Skid duty, head and power
Required head per 23 25 16 cl.3.2 d: static lift (M-ISO) + Darcy/Colebrook loss of the single-leg main path at total flow (with sum L/D equivalent length) + components left in the path (M-602 square law) + each skid's own 300 ft lay-flat hose and 40-mesh strainer at its share of flow (VD-05). Skid head from the VD-01/VD-02 curves by linear interpolation; no duty beyond the last tabulated point. Power from SW-04/E-701 (simultaneous load at the panel).

| Circuit | Stage group | Skid | Q gpm | Static | Main path | Components | Hose | Strainer | Required ft | Available ft | Head margin | kW / panel kW |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| C1 | flush/clean | FS-1200-A | 1185 | 26 | 11.17 | 0.00 | 8.55 | 42.91 | 88.62 | 119.10 | 0.2559 | 75 / 150 |
| C1 | FINAL_FILL (bypasses removed) | FS-600-A | 450 | 26 | 1.86 | 0.00 | 44.71 | 6.19 | 78.76 | 141.00 | 0.4414 | 30 / 150 |
| C2 | flush/clean | FS-1200-A | 625 | 22 | 12.54 | 0.00 | 2.43 | 11.94 | 48.90 | 185.58 | 0.7365 | 75 / 150 |
| C2 | DRAIN_RINSE | FS-600-A+FS-600-B | 625 | 22 | 12.54 | 0.00 | 21.73 | 2.98 | 59.25 | 161.17 | 0.6324 | 60 / 150 |
| C2 | FINAL_FILL (bypasses removed) | FS-600-A | 400 | 22 | 5.44 | 19.78 | 35.41 | 4.89 | 87.52 | 148.33 | 0.4100 | 30 / 150 |
| C3 | flush/clean | FS-1200-A | 722 | 22 | 15.65 | 0.00 | 3.22 | 15.93 | 56.81 | 176.21 | 0.6776 | 75 / 95 |
| C3 | FINAL_FILL (bypasses removed) | FS-600-A | 400 | 22 | 5.18 | 19.78 | 35.41 | 4.89 | 87.25 | 148.33 | 0.4118 | 30 / 95 |
| C4 | flush/clean | FS-600-A | 362 | 48 | 18.37 | 0.00 | 29.06 | 4.00 | 99.43 | 153.91 | 0.3540 | 30 / 90 |
| C4 | FINAL_FILL (bypasses removed) | FS-600-A | 250 | 48 | 9.19 | 38.95 | 13.99 | 1.91 | 112.05 | 167.33 | 0.3304 | 30 / 90 |
| C5 | flush/clean | FS-600-A | 477 | 44 | 29.04 | 0.00 | 50.19 | 6.95 | 130.18 | 134.70 | 0.0336 | 30 / 90 |
| C5 | FINAL_FILL (bypasses removed) | FS-600-A | 250 | 44 | 8.64 | 43.40 | 13.99 | 1.91 | 111.94 | 167.33 | 0.3310 | 30 / 90 |
| C6 | flush/clean | FS-600-A | 362 | 48 | 21.47 | 0.00 | 29.06 | 4.00 | 102.53 | 153.91 | 0.3338 | 30 / 90 |
| C6 | FINAL_FILL (bypasses removed) | FS-600-A | 250 | 48 | 10.75 | 40.28 | 13.99 | 1.91 | 114.93 | 167.33 | 0.3132 | 30 / 90 |
| C7 | flush/clean | FS-600-A | 297 | 72 | 13.17 | 0.00 | 19.65 | 2.70 | 107.51 | 163.26 | 0.3415 | 30 / 45 |
| C7 | FINAL_FILL (bypasses removed) | FS-600-A | 220 | 72 | 7.53 | 31.75 | 10.88 | 1.48 | 123.64 | 169.93 | 0.2724 | 30 / 45 |
| C8 | flush/clean | FS-600-A | 152 | 14 | 37.81 | 9.63 | 5.27 | 0.71 | 67.41 | 175.83 | 0.6166 | 30 / 120 |
| C8 | FINAL_FILL (bypasses removed) | FS-600-A | 152 | 14 | 37.81 | 9.63 | 5.27 | 0.71 | 67.41 | 175.83 | 0.6166 | 30 / 120 |

Rejected skid options (recorded for the design basis): C1 cannot be flushed by two FS-600 in parallel (each needs 124.5 ft at 591 gpm against 108.2 ft available) and FS-1200-A is the only single unit able to deliver 1,181 gpm; C3 at 720 gpm is beyond the last FS-600 curve point (700 gpm); C2 on one FS-600 needs 131.8 ft against 98.4 ft; C7 (ROOF, 45 kW) can only take one FS-600 (30 kW) - an FS-1200 (75 kW) or two FS-600 (60 kW) exceed the panel. FS-1200-A is not used before hour 48 (SI-05).

Components left in the flushed path: PMP-101 and BT-101 (C1) show zero rated drop (M-602 Note 5) against limits of 40/15 ft; ST-601 (C8) develops 6 x (152/120)^2 = 9.6 ft against 25 ft allowed; all are rated 800 micron (strainer 380 micron), 140-200 degF (flush water 68 degF) and >= 150 psig. Components with bypass provision (HX-201A/B, CDU-301/302, CP-311/321/331, CL-401) are spooled out for the initial flush and cleaning and the spools stay in through rinse and passivation (the FLUSH volume excludes them, cl.3.6). At the flushing flows several of them would exceed their M-602 limits (HX-201B 64.2 ft > 58 ft at 722 gpm; CDU-302 66 ft > 48 ft and CP-321 91 ft > 65 ft at 477 gpm; CP-331 84 ft > 72 ft at 362 gpm; CL-401 58 ft > 52 ft at 297 gpm), so the turnover fill is run at a reduced flow chosen to keep every reinstated component inside its allowable drop and the skid inside its curve (table above, FINAL_FILL rows); 23 25 16 cl.3.3 requires the flushing flow only through flush, cleaning and rinse.

### 4.3 Hydrostatic testing
CX-02 records all eight circuits as PASS at 127.5 psig for 120 min, but 01 91 13 cl.1.3 accepts a result only with its cited evidence on file. Charts TR-0412 (C1), TR-0413 (C2), TR-0415 (C4) and TR-0419 (C8) are on file (scanned, read as images) and those circuits are not retested (23 21 16 cl.3.3: retesting an accepted circuit is a scope change). TR-0414 (C3), TR-0416 (C5), TR-0417 (C6) and TR-0418 (C7) are not on file, so C3, C5, C6 and C7 are tested before chemical cleaning and before TM-1 (day 6): 1.5 x 85 = 127.5 psig (>= 125 psig) held 120 minutes, water V_f, below the lowest rating in the assembled circuit (150 psig hose/strainer/skid, VD-05 note 1; HX-201B 230 psig; others 300 psig). The test pump is contractor-provided lump-sum scope (cl.3.10 f).

### 4.4 Chemical cleaning
Cleaner per metallurgy (VD-06, UFC para 10-1.1): CL-100 alkaline (pH 10.4) at 1.5 gal per 1,000 gal of SYSTEM volume for C1-C5 and C7; CL-210 neutral at 2.0 gal per 1,000 gal for C6 (aluminium cold plates CP-331 are part of the circuit metallurgy even though spooled out) and C8 (galvanized). PD-45 polyacrylate dispersant carried with the charge at 5 ppm active polymer on the system volume (UFC para 5-3.7, "about 4 to 5 ppm"). Circulation 24.0 occupied hours (UFC para 5-7.3.2.2 b) at the flushing flow, then drain and clean the strainer basket (VD-05 note 2).

### 4.5 Rinse model and cascades
C_n = C_mk + (C_0 - C_mk) exp(-eta n), C_mk = 615 microS/cm (SW-02), C_0 = 2,600 (CL-100) / 2,150 (CL-210) microS/cm (VD-06 Note 3). Acceptance (UFC para 5-7.3.2.2 e): conductivity within +10 % of makeup = 676.5 microS/cm; pH 7.6 +/- 0.3 inside the 7.5-8.5 window, controlled to the intersection 7.5-7.9 (23 25 16 cl.3.6). eta = 0.45 for C4, C5, C6 (cold-plate manifold banks) and C7 (coil bank, M-602), 0.62 for C1, C2, C3, C8.

| Circuit | Cleaner | eta | n required (real) | n_r | C_n microS/cm | Margin (conductivity) | Margin (displacements) | Cascade |
|---|---|---|---|---|---|---|---|---|
| C1 | CL-100 | 0.62 | 5.604 | 6 | 663.1 | 0.0198 | 0.0707 | donates to C5 |
| C2 | CL-100 | 0.62 | 5.604 | 6 | 663.1 | 0.0198 | 0.0707 | receives from C8; donates to C6 |
| C3 | CL-100 | 0.62 | 5.604 | 6 | 663.1 | 0.0198 | 0.0707 | receives from C5; donates to C4 |
| C4 | CL-100 | 0.45 | 7.721 | 8 | 669.2 | 0.0107 | 0.0362 | receives from C3; donates to C8 |
| C5 | CL-100 | 0.45 | 7.721 | 8 | 669.2 | 0.0107 | 0.0362 | receives from C1; donates to C3 |
| C6 | CL-210 | 0.45 | 7.149 | 8 | 656.9 | 0.0289 | 0.1190 | receives from C2; donates to C7 |
| C7 | CL-100 | 0.45 | 7.721 | 8 | 669.2 | 0.0107 | 0.0362 | receives from C6 |
| C8 | CL-210 | 0.62 | 5.189 | 6 | 652.2 | 0.0359 | 0.1563 | receives from C4; donates to C2 |

The SW-03 Rev B programme cap (500,000 gal at MH-14) is below the sewer total of the programme without cascades (534,550 gal). Each cascade lowers both the donor effluent and the receiver draw by the receiver FLUSH volume (cl.3.9). Because a donor FLUSH volume must be at least its receiver's and each circuit donates and receives at most once, the only way to recover enough volume is the full descending chain C1 > C5 > C3 > C4 > C8 > C2 > C6 > C7 (7 cascades, 38,266 gal), which brings the sewer total to 496,284 gal. Dropping any single link would put the programme 370 gal or more over the cap and force tanker haulage at $168/kgal. Each receiver's rinse starts only after its donor's rinse is complete; the donor final-rinse water is moved between tie-ins in the contractor's portable holding tank (cl.3.10 f, not priced).

### 4.6 Treatment programme and passivation
Makeup (SW-02): chloride 505 + sulfate 355 = 860 mg/L, hardness 288 mg/L as CaCO3, silica 11 mg/L. Nitrite-azole is not recommended above (Cl + SO4) 800 ppm (UFC para 6-2.2.2) and the nitrite-molybdate blend is avoided when (Cl + SO4) > (NO2 + Mo) - 100 = 275-375 ppm (para 6-2.2.4); sulfite-caustic is a hot-water programme at pH 9-10. Selection by paragraph text (23 25 16 cl.3.5):
- C6: polysilicate-azole - "especially beneficial when aluminum metal is present" (para 6-2.2.5) and the only programme compatible with the VD-04 cold-plate pH limit 7.0-8.5 (molybdate-azole runs at pH 8.5-9.5). Silica 11 mg/L is far below the 150 ppm restriction.
- C8: polysilicate-azole (azole omitted - no copper wetted). Systems containing galvanized steel are not to be subjected to procedures requiring pH above 8.5 (UFC para 10-1.1, general to all water systems); molybdate-azole must be run at pH 8.5-9.5 (para 6-2.2.3) and would breach this, whereas polysilicate-azole (pH 7.5-8.9, para 6-2.2.5) is controlled at 7.5-8.5. (The open-tower guidance of para 5-7.3.1/5-7.3.2 - white rust above pH 8.5, polysilicate passivation of galvanizing - points the same way but is not relied on, cl.1.1.)
- C1-C5, C7: molybdate-azole (para 6-2.2.3), the chilled/closed-water programme of Table 6-2 left after the nitrite exclusions; tolyltriazole is carried on C4, C5, C7 (and C6) where copper is wetted (copper pipe 4024/4034/4043/5013, CDU and cold-plate copper).
All programmes require softened makeup above 250 ppm hardness (para 6-2.2.3/6-2.2.5, Table 6-1): the turnover top-up water is drawn through softened outlet SV-2 (C-101), whose SF-1 capacity of 88,000 grains per daily regeneration supports 5,230 gal/day at 288 mg/L; the turnover fills are spread over days so that no day exceeds that volume.

Passivation per the tables UFC 3-230-13 identifies for passivation (para 5-7.3.2.4: Tables 5-14 and 5-15; 23 25 16 cl.3.5): molybdate 40-60 ppm as Mo or polysilicate 40-50 ppm as SiO2 at pH 7.5-8.5, tolyltriazole 10-20 ppm at pH 6.5-7.9, film formation 14-21 days. Where TTA is carried the pH is controlled to the intersection 7.5-7.9 (cl.3.8). The 14-day minimum (336 occupied hours) of the current edition is held; Table 5-11 (10-12 days, a maintenance-dosage table for open towers) is not used. All doses are referred to the SYSTEM volume (cl.3.5); the charge is dosed into the water standing at the end of the rinse and circulated V_f at the flushing flow plus 30 minutes before the start-of-film-formation sample.

| Circuit | Programme | Passivation residual | TTA | Passivation pH | Maintenance residual | Maintenance pH | Packages (inhibitor pass/turnover) |
|---|---|---|---|---|---|---|---|
| C1 | MOLYBDATE-AZOLE | 50 ppm as Mo (MO-500) | not required | 7.5-8.5 | 109 ppm | 8.5-9.5 | 3 / 3 |
| C2 | MOLYBDATE-AZOLE | 50 ppm as Mo (MO-500) | not required | 7.5-8.5 | 110 ppm | 8.5-9.5 | 1 / 1 |
| C3 | MOLYBDATE-AZOLE | 50 ppm as Mo (MO-500) | not required | 7.5-8.5 | 110 ppm | 8.5-9.5 | 1 / 1 |
| C4 | MOLYBDATE-AZOLE | 50 ppm as Mo (MO-500) | 15 ppm | 7.5-7.9 | 110 ppm | 8.5-9.5 | 1 / 1 |
| C5 | MOLYBDATE-AZOLE | 50 ppm as Mo (MO-500) | 15 ppm | 7.5-7.9 | 110 ppm | 8.5-9.5 | 1 / 1 |
| C6 | POLYSILICATE-AZOLE | 45 ppm as SiO2 (PS-330) | 15 ppm | 7.5-7.9 | 87 ppm | 7.5-8.5 | 1 / 1 |
| C7 | MOLYBDATE-AZOLE | 50 ppm as Mo (MO-500) | 15 ppm | 7.5-7.9 | 110 ppm | 8.5-9.5 | 1 / 1 |
| C8 | POLYSILICATE-AZOLE | 45 ppm as SiO2 (PS-330) | not required | 7.5-8.5 | 87 ppm | 7.5-8.5 | 1 / 1 |

### 4.7 Turnover
RETAIN_AND_TOP_UP on every circuit (23 25 16 cl.3.8): the maintenance residual of both programmes (Mo 100-125 ppm, SiO2 80-100 ppm) is above the passivation residual, so the top-up raises the level; the azole is held at the same 15 ppm (>= 10 ppm minimum) so it is not diluted. Bypass spools are removed, the components are filled with softened makeup carrying the maintenance increment (product_quantity = increment; target_ppm = absolute residual, basis = SYSTEM volume), and the circuit is recirculated 30 minutes before sampling while circulating (UFC para 5-7.3.2.2 d). Draw = V_s - V_f, effluent 0. DRAIN_AND_REFILL was rejected: it would discharge the molybdate passivation charge (40-60 mg/L Mo against the 0.5 mg/L SW-03 local limit - haul at $168/kgal), draw the whole system volume, and exceed the SV-2 softener capacity many times over. The pH of the molybdate circuits is brought into 8.5-9.5 by the buffered maintenance charge with field verification. Temporary strainers are removed at the end of each turnover fill, before TM-4.

### 4.8 Discharge
Authorised point MH-14 (SW-03 Rev B, RFI-031). Local limits (instantaneous): pH 6.0-9.0, <= 104 degF, Mo 0.5, Zn 1.0, Cu 1.0, TSS 300 mg/L; 40 CFR 403.5(b) prohibitions (pH >= 5.0, <= 104 degF at the POTW) apply and the local limits are the more restrictive. The spent cleaning solution of every circuit whose flushed path includes copper pipe (C4, C5, C6, C7: 3.4 mg/L Cu with CL-100, 1.6 mg/L with CL-210) or galvanizing (C8: 5.5 mg/L Zn with CL-210) cannot meet the copper/zinc limit and is collected by vacuum tanker at the YARD pad (C-101) - 26,466 gal. Hydro, flush, rinse and the C1-C3 spent cleaner (pH 8.4, no Cu/Zn) go to MH-14: 496,284 gal against the 500,000 gal cap. The rinse effluent runs from spent solution to makeup quality (pH between 8.4 and 7.6, ambient 68 degF). Passivation and turnover produce no effluent (RETAIN_AND_TOP_UP). Every discharge event is sampled before release and logged with volume, pH and temperature (SW-03 general conditions 3-4; CX-03 item 9). No discharge to storm or Tull Creek.

### 4.9 Water
Total draw 607,259 gal = effluent 522,750 gal + standing system volume 84,509 gal (cl.3.9 balance). Daily limit 92,000 gal (62,000 metered + 30,000 trucked, SW-01 s.1-2), reduced by SI-04 to 61,000 gal on days 2-3 and 30,000 gal (trucked only) on day 6. Draws spanning midnight are pro-rated by hours. Metered 510,067 gal, trucked 97,193 gal; programme-average rate $8.3767/kgal applied to every circuit (cl.3.10 c).

| Day | Draw gal | Metered | Trucked | Day limit | Margin |
|---|---|---|---|---|---|
| 4 | 65,321 | 62,000 | 3,321 | 92,000 | 0.2900 |
| 5 | 87,535 | 62,000 | 25,535 | 92,000 | 0.0485 |
| 7 | 78,076 | 62,000 | 16,076 | 92,000 | 0.1513 |
| 8 | 89,472 | 62,000 | 27,472 | 92,000 | 0.0275 |
| 9 | 84,104 | 62,000 | 22,104 | 92,000 | 0.0858 |
| 10 | 11,323 | 11,323 | 0 | 92,000 | 0.8769 |
| 11 | 52,262 | 52,262 | 0 | 92,000 | 0.4319 |
| 12 | 64,685 | 62,000 | 2,685 | 92,000 | 0.2969 |
| 13 | 61,221 | 61,221 | 0 | 92,000 | 0.3346 |
| 28 | 5,160 | 5,160 | 0 | 92,000 | 0.9439 |
| 29 | 4,700 | 4,700 | 0 | 92,000 | 0.9489 |
| 30 | 3,400 | 3,400 | 0 | 92,000 | 0.9630 |

### 4.10 Margins and governing constraint
Relative margin = (limit - achieved)/limit for an upper limit, (achieved - limit)/limit for a lower limit (23 25 16 cl.1.6). Flushing duty: (skid head available - required head)/available at the flushing flow (least of flush, clean and rinse). Rinse: in conductivity (676.5 - C_n)/676.5, and in displacements (n_r - n_required)/n_required; the conductivity form is the tighter and is the one stated. Discharge: (500,000 - programme sewer total)/500,000. Water: least (limit - draw)/limit over the days the circuit draws. Power: (panel kW - simultaneous kW at the tie-in panel)/panel kW.

| Circuit | Flushing duty (head) | Rinse (conductivity) | Rinse (displacements) | Discharge volume | Daily water | Temporary power | Governing |
|---|---|---|---|---|---|---|---|
| C1 | 0.2559 | 0.0198 | 0.0707 | 0.00743 | 0.0275 (day 8) | 0.5000 | authorised programme discharge volume |
| C2 | 0.6324 | 0.0198 | 0.0707 | 0.00743 | 0.0275 (day 8) | 0.5000 | authorised programme discharge volume |
| C3 | 0.6776 | 0.0198 | 0.0707 | 0.00743 | 0.0275 (day 8) | 0.2105 | authorised programme discharge volume |
| C4 | 0.3540 | 0.0107 | 0.0362 | 0.00743 | 0.4319 (day 11) | 0.6667 | authorised programme discharge volume |
| C5 | 0.0336 | 0.0107 | 0.0362 | 0.00743 | 0.0275 (day 8) | 0.6667 | authorised programme discharge volume |
| C6 | 0.3338 | 0.0289 | 0.1190 | 0.00743 | 0.0485 (day 5) | 0.6667 | authorised programme discharge volume |
| C7 | 0.3415 | 0.0107 | 0.0362 | 0.00743 | 0.0485 (day 5) | 0.3333 | authorised programme discharge volume |
| C8 | 0.6166 | 0.0359 | 0.1563 | 0.00743 | 0.2969 (day 12) | 0.7500 | authorised programme discharge volume |

GOVERNING CONSTRAINT C1: authorised programme discharge volume (margin 0.00743)

GOVERNING CONSTRAINT C2: authorised programme discharge volume (margin 0.00743)

GOVERNING CONSTRAINT C3: authorised programme discharge volume (margin 0.00743)

GOVERNING CONSTRAINT C4: authorised programme discharge volume (margin 0.00743)

GOVERNING CONSTRAINT C5: authorised programme discharge volume (margin 0.00743)

GOVERNING CONSTRAINT C6: authorised programme discharge volume (margin 0.00743)

GOVERNING CONSTRAINT C7: authorised programme discharge volume (margin 0.00743)

GOVERNING CONSTRAINT C8: authorised programme discharge volume (margin 0.00743)

The discharge margin is a programme quantity shared by all circuits; it is the least margin for every circuit because the cap is met only with the full cascade chain. The next-tightest constraint is the rinse endpoint in conductivity for C4, C5 and C7 (0.0107) and the C5 flushing duty on one FS-600 (head margin above).

## 5. Conflicts between documents and their resolution
1. Sewer cap: RFI-031 (2026-07-06) and SW-03 original issue state 540,000 gal; SW-03 Rev B (2026-07-21) s.2 supersedes it with 500,000 gal. Rev B governs; local limits of the original remain in force by Rev B s.3.
2. Hydrostatic record: CX-02 lists C3, C5, C6, C7 as PASS but their charts (TR-0414/0416/0417/0418) are not on file; 01 91 13 cl.1.3 governs - tests repeated. C1, C2, C4, C8 (charts on file) are not retested (23 21 16 cl.3.3).
3. M-PID-103 Rev A vs Rev C: line 4033 moves from C4 (x2) to C5 (x3). Rev C governs (M-601 Note 5); C5 is governed by 4033.
4. UFC 3-230-13 Table 6-2 lists polysilicate-azole only for diesel jackets while para 6-2.2.5 recommends it where aluminium is present: paragraph text governs (23 25 16 cl.3.5) - C6 polysilicate-azole.
5. Film-formation time: Table 5-11 (10-12 days) vs Tables 5-14/5-15 (14-21 days). The passivation tables govern (cl.3.5) - 14 days.
6. Rinse pH: tolerance (7.6 +/- 0.3 = 7.3-7.9) vs window (7.5-8.5): controlled to the intersection 7.5-7.9 (cl.3.6).
7. pH bands of two inhibitors (molybdate/polysilicate 7.5-8.5 vs TTA 6.5-7.9): intersection 7.5-7.9 (cl.3.8); C6 maintenance additionally limited by VD-04 (7.0-8.5) to 7.5-8.5.
8. SW-01 s.1 calls 62,000 gal the allocation while s.2 makes 92,000 gal the daily draw limit: 62,000 gal is the price break, 92,000 gal (SI-04: 61,000/61,000/30,000 on days 2/3/6) is the limit used for feasibility and margins.
9. VD-03/VD-04 quote the drop each component develops at rated flow; M-602 Max Allowable governs (M-602 Note 6, VD-03 note 5).
10. M-602 shows a 40/15 ft "max allowable" for PMP-101/BT-101 with zero rated drop: per Note 5 these are casing ratings, not flushing limits; both stay in the path.
11. 40 CFR 403.5(b)(2) floor pH 5.0 vs SW-03 local limit 6.0: the more restrictive (6.0) governs (SW-03 general condition 1, 23 25 16 cl.1.1).

## 6. Defects found in the documents
- CX-02 reports results whose evidence (charts TR-0414, TR-0416, TR-0417, TR-0418) is missing.
- UFC 3-230-13 Table 5-14 prints "days" for the orthophosphate and tolyltriazole dosage units (should be ppm); read as ppm.
- UFC 3-230-13 Table 6-1 carries a second hardness line (< 50 ppm) without a system type; the chilled-water 250 ppm line is used.
- RFI-031 repeats the superseded 540,000 gal programme total.
- M-PID-103 Rev A remains in the drawing set, marked superseded.
- VD-06 lists NB-700 with density 0 and offers it without regard to the makeup chemistry (Note 4); not suitable.
- VD-03 notes are numbered out of sequence (note 5 printed before note 2).
- M-ISO sheets show the ROOF tie-in at the grade datum (+0'-0"); the static lift is taken as the elevation difference shown (72 ft), per the sheet note.

## 7. Judgement calls
- Flows declared a little above the computed minimum (velocity margin 0.1-0.6 %) to keep skid duty margins and rinse times favourable; head from linear interpolation of the published curves.
- One initial-flush displacement (cl.3.3 minimum); cleaning, rinse and passivation at the flushing flow on the same skid wherever possible.
- C1 rinse (197,900 gal) split into three activities of two displacements on separate days so that no day exceeds 92,000 gal.
- Rinse effluent sewered: the copper/zinc of VD-06 Note 3 is carried by the spent solution (hauled); the rinse runs down to makeup quality.
- Turnover fills at reduced flow with components reinstated (component limits govern; velocity requirement of cl.3.3 does not extend to the fill). Fine filtration (25 micron) is fitted for reinstatement of CDU (300 micron) and cold plates (50 micron); excluded from price (cl.3.10 f).
- Passivation and maintenance residuals chosen inside the bands at the package optimum (whole pails per dosing row, cl.3.10 e).
- No water is drawn on SI-04 day 6 (trucked water only) or on the reduced-allocation days 2-3; the C1 rinse portions fall on days 5, 7 and 8 and the four owed hydrostatic tests on day 5, inside TM-1.
- Where a circuit must wait for its place in the cascade chain (C3, C2, C7), the spent cleaning solution (pH 8.1-8.4, inhibited) is held in the isolated, vented circuit and drained at the start of its rinse; the rinse count and acceptance test are unchanged.
- Film-formation holds run from the end of passivation to the turnover fill and are kept between 14 and 21 days (the Table 5-15 range); turnover fills are grouped on three days to respect the SV-2 softener capacity.
- Spent-cleaner temperature: pump heat over 24 h circulation is estimated at 10-20 degF above the 68 degF makeup; every discharge is measured before release against the 104 degF limit and held to cool if necessary.

## 8. Execution narrative
Per circuit, in this order: (1) lock out at TI-Cx-01/02, connect skid and lay-flat hose at the tie-in, fit the bypass spools and the 40-mesh strainer, verify panel load; (2) hydrostatic test where owed; (3) initial flush, one displacement at the declared flow, to MH-14; (4) make up the cleaning charge (cleaner on system volume + PD-45), circulate 24 h, record circulation time; drain spent solution to the route shown (tanker at the YARD pad for C4-C8), clean the strainer; (5) rinse displacements at the flushing flow (the first displacement of each receiver is the donor's final-rinse water), test conductivity/pH/clarity/SS against makeup at the low-point drain; (6) dose passivation inhibitor (+TTA) into the standing water, circulate V_f plus 30 min, record residual and pH at start of film formation; release the skid; (7) hold 14 days isolated; (8) remove spools, fit fine filter where required, top up with softened makeup carrying the maintenance increment, recirculate 30 min, sample (residual, pH, bacteria), remove the temporary strainer, hand over.

Per-circuit summary (hours from mobilisation):

| Circuit | Hydro | Flush start | Clean end | Rinse window | Passivation end | Hold h (days) | Turnover fill | Skids (flush/clean; rinse/passivate; fill) |
|---|---|---|---|---|---|---|---|---|
| C1 | accepted (chart on file) | 96.00 | 120.47 | 121.00-121.93, 168.00-168.93, 194.00-194.93 | 224.97 | 471.0 (19.6) | 696.00-696.50 | FS-1200-A; FS-1200-A; FS-600-A |
| C2 | accepted (chart on file) | 195.00 | 219.15 | 303.00-303.90 | 304.55 | 391.9 (16.3) | 696.50-697.10 | FS-1200-A; FS-600-A+FS-600-B; FS-600-A |
| C3 | 124.0-126.0 | 169.00 | 193.15 | 220.00-220.86 | 221.51 | 475.6 (19.8) | 697.10-697.70 | FS-1200-A; FS-1200-A; FS-600-A |
| C4 | accepted (chart on file) | 245.00 | 269.28 | 270.00-272.20 | 272.98 | 399.0 (16.6) | 672.00-672.68 | FS-600-A; FS-600-A; FS-600-A |
| C5 | 127.0-129.0 | 192.00 | 216.23 | 217.00-218.80 | 219.53 | 453.1 (18.9) | 672.68-673.36 | FS-600-A; FS-600-A; FS-600-A |
| C6 | 129.0-131.0 | 305.00 | 329.20 | 330.00-331.56 | 332.26 | 387.7 (16.2) | 720.00-720.60 | FS-600-A; FS-600-A; FS-600-A |
| C7 | 122.0-124.0 | 220.00 | 244.23 | 333.00-334.84 | 335.57 | 385.0 (16.0) | 720.60-721.25 | FS-600-A; FS-600-A; FS-600-A |
| C8 | accepted (chart on file) | 273.00 | 297.64 | 298.00-301.81 | 302.95 | 394.8 (16.4) | 697.70-698.20 | FS-600-A; FS-600-A; FS-600-A |

| Activity | Circuit | Stage | Start h | Finish h | Skid | Crew | Water gal |
|---|---|---|---|---|---|---|---|
| C1-INITIAL_FLUSH | C1 | INITIAL_FLUSH | 96.000 | 96.470 | FS-1200-A | CREW-1 | 32,983 |
| C1-CHEM_CLEAN | C1 | CHEM_CLEAN | 96.470 | 120.470 | FS-1200-A | CREW-1 | 32,983 |
| C1-DRAIN_RINSE-1 | C1 | DRAIN_RINSE | 121.000 | 121.930 | FS-1200-A | CREW-1 | 65,967 |
| C7-HYDRO | C7 | HYDRO | 122.000 | 124.000 | - | CREW-1 | 4,086 |
| C3-HYDRO | C3 | HYDRO | 124.000 | 126.000 | - | CREW-1 | 6,203 |
| C5-HYDRO | C5 | HYDRO | 127.000 | 129.000 | - | CREW-1 | 6,406 |
| C6-HYDRO | C6 | HYDRO | 129.000 | 131.000 | - | CREW-1 | 4,227 |
| C1-DRAIN_RINSE-2 | C1 | DRAIN_RINSE | 168.000 | 168.930 | FS-1200-A | CREW-1 | 65,967 |
| C3-INITIAL_FLUSH | C3 | INITIAL_FLUSH | 169.000 | 169.150 | FS-1200-A | CREW-1 | 6,203 |
| C3-CHEM_CLEAN | C3 | CHEM_CLEAN | 169.150 | 193.150 | FS-1200-A | CREW-1 | 6,203 |
| C5-INITIAL_FLUSH | C5 | INITIAL_FLUSH | 192.000 | 192.230 | FS-600-A | CREW-2 | 6,406 |
| C5-CHEM_CLEAN | C5 | CHEM_CLEAN | 192.230 | 216.230 | FS-600-A | CREW-2 | 6,406 |
| C1-DRAIN_RINSE-3 | C1 | DRAIN_RINSE | 194.000 | 194.930 | FS-1200-A | CREW-1 | 65,967 |
| C2-INITIAL_FLUSH | C2 | INITIAL_FLUSH | 195.000 | 195.150 | FS-1200-A | CREW-1 | 5,596 |
| C2-CHEM_CLEAN | C2 | CHEM_CLEAN | 195.150 | 219.150 | FS-1200-A | CREW-1 | 5,596 |
| C5-DRAIN_RINSE | C5 | DRAIN_RINSE | 217.000 | 218.800 | FS-600-A | CREW-2 | 44,841 |
| C5-PASSIVATE | C5 | PASSIVATE | 218.800 | 219.530 | FS-600-A | CREW-2 | 0 |
| C5-HOLD | C5 | HOLD | 219.530 | 672.680 | - | - | 0 |
| C3-DRAIN_RINSE | C3 | DRAIN_RINSE | 220.000 | 220.860 | FS-1200-A | CREW-1 | 31,016 |
| C7-INITIAL_FLUSH | C7 | INITIAL_FLUSH | 220.000 | 220.230 | FS-600-A | CREW-2 | 4,086 |
| C7-CHEM_CLEAN | C7 | CHEM_CLEAN | 220.230 | 244.230 | FS-600-A | CREW-2 | 4,086 |
| C3-PASSIVATE | C3 | PASSIVATE | 220.860 | 221.510 | FS-1200-A | CREW-1 | 0 |
| C3-HOLD | C3 | HOLD | 221.510 | 697.100 | - | - | 0 |
| C1-PASSIVATE | C1 | PASSIVATE | 224.000 | 224.970 | FS-1200-A | CREW-1 | 0 |
| C1-HOLD | C1 | HOLD | 224.970 | 696.000 | - | - | 0 |
| C4-INITIAL_FLUSH | C4 | INITIAL_FLUSH | 245.000 | 245.280 | FS-600-A | CREW-2 | 5,957 |
| C4-CHEM_CLEAN | C4 | CHEM_CLEAN | 245.280 | 269.280 | FS-600-A | CREW-2 | 5,957 |
| C4-DRAIN_RINSE | C4 | DRAIN_RINSE | 270.000 | 272.200 | FS-600-A | CREW-2 | 41,696 |
| C4-PASSIVATE | C4 | PASSIVATE | 272.200 | 272.980 | FS-600-A | CREW-2 | 0 |
| C4-HOLD | C4 | HOLD | 272.980 | 672.000 | - | - | 0 |
| C8-INITIAL_FLUSH | C8 | INITIAL_FLUSH | 273.000 | 273.640 | FS-600-A | CREW-2 | 5,791 |
| C8-CHEM_CLEAN | C8 | CHEM_CLEAN | 273.640 | 297.640 | FS-600-A | CREW-2 | 5,791 |
| C8-DRAIN_RINSE | C8 | DRAIN_RINSE | 298.000 | 301.810 | FS-600-A | CREW-2 | 28,954 |
| C8-PASSIVATE | C8 | PASSIVATE | 301.810 | 302.950 | FS-600-A | CREW-2 | 0 |
| C8-HOLD | C8 | HOLD | 302.950 | 697.700 | - | - | 0 |
| C2-DRAIN_RINSE | C2 | DRAIN_RINSE | 303.000 | 303.900 | FS-600-A+FS-600-B | CREW-2 | 27,980 |
| C2-PASSIVATE | C2 | PASSIVATE | 303.900 | 304.550 | FS-600-A+FS-600-B | CREW-2 | 0 |
| C2-HOLD | C2 | HOLD | 304.550 | 696.500 | - | - | 0 |
| C6-INITIAL_FLUSH | C6 | INITIAL_FLUSH | 305.000 | 305.200 | FS-600-A | CREW-2 | 4,227 |
| C6-CHEM_CLEAN | C6 | CHEM_CLEAN | 305.200 | 329.200 | FS-600-A | CREW-2 | 4,227 |
| C6-DRAIN_RINSE | C6 | DRAIN_RINSE | 330.000 | 331.560 | FS-600-A | CREW-2 | 29,590 |
| C6-PASSIVATE | C6 | PASSIVATE | 331.560 | 332.260 | FS-600-A | CREW-2 | 0 |
| C6-HOLD | C6 | HOLD | 332.260 | 720.000 | - | - | 0 |
| C7-DRAIN_RINSE | C7 | DRAIN_RINSE | 333.000 | 334.840 | FS-600-A | CREW-2 | 28,602 |
| C7-PASSIVATE | C7 | PASSIVATE | 334.840 | 335.570 | FS-600-A | CREW-2 | 0 |
| C7-HOLD | C7 | HOLD | 335.570 | 720.600 | - | - | 0 |
| C4-FINAL_FILL | C4 | FINAL_FILL | 672.000 | 672.680 | FS-600-A | CREW-1 | 2,580 |
| C5-FINAL_FILL | C5 | FINAL_FILL | 672.680 | 673.360 | FS-600-A | CREW-1 | 2,580 |
| C1-FINAL_FILL | C1 | FINAL_FILL | 696.000 | 696.500 | FS-600-A | CREW-1 | 0 |
| C2-FINAL_FILL | C2 | FINAL_FILL | 696.500 | 697.100 | FS-600-A | CREW-1 | 2,350 |
| C3-FINAL_FILL | C3 | FINAL_FILL | 697.100 | 697.700 | FS-600-A | CREW-1 | 2,350 |
| C8-FINAL_FILL | C8 | FINAL_FILL | 697.700 | 698.200 | FS-600-A | CREW-1 | 0 |
| C6-FINAL_FILL | C6 | FINAL_FILL | 720.000 | 720.600 | FS-600-A | CREW-1 | 1,450 |
| C7-FINAL_FILL | C7 | FINAL_FILL | 720.600 | 721.250 | FS-600-A | CREW-1 | 1,950 |

Units held (calendar days): FS-600-A: [8, 9, 10, 11, 12, 13, 28, 29, 30]; FS-600-B: [12]; FS-1200-A: [4, 5, 7, 8, 9].
Crew shifts: CREW-1: [8, 9, 10, 14, 15, 16, 17, 18, 56, 58, 60]; CREW-2: [16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27].

## 9. Cost (23 25 16 cl.3.10)
Skid rental $8,250.00; crew $18,860.00; water $5,086.83; effluent $9,111.41; chemicals $7,500.00; TOTAL $48,808.25.

| Circuit | Skid rental | Crew | Water | Effluent | Chemicals | Total |
|---|---|---|---|---|---|---|
| C1 | 1,876.37 | 2,221.92 | 2,210.34 | 2,110.09 | 2,198.00 | 10,616.72 |
| C2 | 1,736.89 | 2,279.67 | 347.82 | 328.48 | 726.00 | 5,418.86 |
| C3 | 1,127.82 | 2,278.45 | 435.38 | 410.49 | 726.00 | 4,978.14 |
| C4 | 719.40 | 2,342.54 | 470.68 | 1,394.22 | 818.00 | 5,744.85 |
| C5 | 697.14 | 2,433.97 | 558.21 | 1,559.80 | 818.00 | 6,067.13 |
| C6 | 716.31 | 2,497.23 | 366.24 | 1,029.37 | 800.00 | 5,409.15 |
| C7 | 729.92 | 2,550.79 | 358.60 | 1,032.11 | 706.00 | 5,377.43 |
| C8 | 646.15 | 2,255.42 | 339.55 | 1,246.84 | 708.00 | 5,195.96 |

## 10. Contractor-provided scope (excluded from the priced comparison, cl.3.10 f)
- Hydrostatic test pump and calibrated recorder for C3, C5, C6, C7 (the flush skids cannot reach 127.5 psig and are rated 150 psig).
- Portable holding tank(s) to move each cascaded displacement from donor to receiver tie-in (seven transfers).
- Fine filtration (25 micron cartridge) at reinstatement of CDU-301/302 (300 micron) and CP-311/321/331 (50 micron), which the 380 micron strainer does not protect.

## 11. Safety - hazard communication (29 CFR 1910.1200, adopted by 23 25 16 cl.1.2)
- Written hazard communication programme (1910.1200(e)(1)) for this scope listing every hazardous chemical brought on site - CL-100, CL-210, MO-500, PS-330, TA-90, PD-45 - with the location of use, quantities on hand, the person responsible, and the method of informing crews of the hazards of non-routine tasks (tank entry, line breaks on charged circuits); NB-700 and SA-100 are not brought to site.
- Multi-employer site (1910.1200(e)(2)): the general contractor and other trades working near MER-1, MER-2, L3-N/S/W, ROOF and YARD are given access to the SDS, told of the precautionary measures (barricaded dosing points, splash zones, eyewash locations) and of the labelling system used.
- Labels (1910.1200(f)): every pail, bag, bottle and dosing pot, including secondary (transfer) containers, labelled with the product identifier, signal word, hazard statements and pictograms; supplier labels are not removed or defaced. Spent-cleaner tanker loads are manifested and marked by the hauler as waste.
- Safety data sheets (1910.1200(g)): the VD-07 SDS for each product kept at the site office and at each active tie-in (MER-1, MER-2, L3-N, L3-S, L3-W, ROOF, YARD) and readily accessible to the crews on every shift; CX-03 item 10 signed before any product is opened.
- Training (1910.1200(h)): both crews trained before first assignment and whenever a new product is introduced - hazards (CL-100 and CL-210: Skin Corr. 1B, Eye Dam. 1, DANGER; inhibitors Eye Irrit. 2A, WARNING), SDS and label reading, PPE, spill and first aid; attendance recorded.
- Controls from the SDS: chemical splash goggles, face shield, chemical-resistant gloves and apron when transferring; emergency eyewash and quick-drench shower within 10 seconds of every handling point (portable units at L3, ROOF and YARD); eyes flushed 15 minutes; emergency number 1-800-555-0142.
- Pressure and process safety: hydrostatic test exclusion zone; never exceed 150 psig in the temporary circuit; lockout of tie-in valves; hoses restrained; electrical connection to the SW-04 panel by the GC electrician; discharge only to MH-14 or tanker, never to storm drains.
