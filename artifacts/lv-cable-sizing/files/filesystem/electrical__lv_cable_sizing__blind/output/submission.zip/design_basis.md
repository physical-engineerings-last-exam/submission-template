```json
{
  "project": "P-4210 Building 4210 Consolidated Support Facility, NSA Whitmore Ridge",
  "sheet": "E-621 Wire schedule (E-600 series)",
  "codes_of_record": {
    "nfpa70_edition": "2023",
    "ibc_edition": "2024",
    "adopted_by": "UFC 1-200-01 DoD Building Code (1 September 2022, Change 4, 17 December 2024) - adopts the 2024 IBC (1-6.1) and directs every IBC reference to NFPA 70 to UFC 3-501-01, which cites NFPA 70 (1-6.2)",
    "precedence": "Where two of the governing documents set different limits for the same thing, the most restrictive requirement governs (G-001 order of precedence; EDS-26 Rev 4 para 1.1); where EDS-26 is silent the UFC governs",
    "nfpa70": "NFPA 70 National Electrical Code, 2023 edition (edition in effect at start of design, 14 July 2025)",
    "ibc": "International Building Code, 2024 edition, as adopted and modified by UFC 1-200-01",
    "other_criteria": [
      "UFC 3-501-01 Electrical Engineering, 27 November 2024",
      "UFC 3-520-01 Interior Electrical Systems, 16 January 2025",
      "UFC 1-200-02 (energy, cites ASHRAE 90.1)",
      "NSA Whitmore Ridge EDS-26 Rev 4, 12 June 2026"
    ],
    "code_of_record_sheet": "G-001",
    "superseded_not_used": [
      "EDS-26 Rev 2 (3 March 2022)",
      "E-601 Rev A one-line (8 February 2026)"
    ],
    "not_basis_of_design": [
      "Meridian Cable datasheet MC-BW-2025"
    ]
  },
  "environment": {
    "outdoor_design_dry_bulb_c": 42,
    "roof_ambient_c": 46,
    "earth_ambient_c": 27.45,
    "soil_thermal_resistivity_k_m_w": 0.6,
    "solar_irradiance_w_m2": 1030,
    "encasement_thermal_resistivity_k_m_w": 0.55,
    "native_soil_thermal_resistivity_rejected_k_m_w": 0.95,
    "interior_ambients_c": {
      "ceiling cavity / E-611, E-612 circuits": 40,
      "mechanical room 121 / fire pump room 105 (F-01, F-03, B-11..B-15)": 45,
      "Building 4212 shop (B-16..B-18)": 40,
      "roof tray": 46
    }
  },
  "sources": {
    "outdoor_design_dry_bulb_c": "NOAA daily normals 1991-2020, USW00003145 (site/): highest DLY-TMAX-NORMAL 106.8 F = 41.56 C rounded up (EDS-26 Rev 4 5.4)",
    "roof_ambient_c": "EDS-26 Rev 4 5.4: outdoor design dry-bulb + 4 K (M-501-C roof row 46 C agrees)",
    "earth_ambient_c": "NOAA daily normals 1991-2020, USW00003145: annual mean of DLY-TAVG-NORMAL 76.00 F = 24.45 C, + 3 K (EDS-26 Rev 4 5.3.2); GEO-4210-T 2.4 logged temperatures not used",
    "soil_thermal_resistivity_k_m_w": "GEO-4210-T 2.2: fluidised thermal backfill 0.60 K.m/W surrounds both encasements (native SP-SM 0.95 K.m/W of 2.1 rejected)",
    "solar_irradiance_w_m2": "EDS-26 Rev 4 5.4 (S = 1030 W/m2, alpha_s = 0.6, h = 14.0 W/m2K)",
    "encasement_thermal_resistivity_k_m_w": "GEO-4210-T 2.3",
    "interior_ambients_c": "M-501-C ambient temperature coordination memorandum (notes 1 and 3), not less than 25 C (UFC 3-520-01 3-6.3.2)"
  },
  "voltage_drop": {
    "start_point": "T-1 secondary lugs - point of government ownership (WRPU-2026-0412; UFC 3-501-01 3-2.7.4.2), nominal 480 V assumed there (3-2.7.4.1)",
    "transformer_reset": false,
    "transformer_reset_basis": "UFC 3-501-01 3-2.7: restart only where voltage is raised above 1000 V; 3-2.7.4.5.3: zero drop through transformers, the K-13 secondary (and DP-3 transformer section) starts at the primary percentage",
    "feeder_chain_pct": {
      "MSB-1": 1.043,
      "MCC-1": 2.575,
      "DP-2": 1.407,
      "K-13": 1.546,
      "LP-1": 2.748,
      "DP-3": 2.581,
      "ATS-1": 2.777
    },
    "feeder_chain_paths": {
      "T-1 to MSB-1 (SE-1)": 1.043,
      "MSB-1 to MCC-1 (SE-1+F-01)": 2.575,
      "MSB-1 to DP-2 (SE-1+F-02)": 1.407,
      "DP-2 to K-13 primary (SE-1+F-02+F-06)": 1.546,
      "K-13 to LP-1 (SE-1+F-02+F-06+F-07)": 2.748,
      "MSB-1 to DP-3 (SE-1+F-05)": 2.581,
      "MSB-1 to ATS-1 (SE-1+F-10)": 2.777
    },
    "feeder_chain_max_pct": 2.777,
    "feeder_limit_pct": 3.0,
    "branch_limit_pct": 3.0,
    "total_limit_pct": 5.0,
    "fire_pump_limits_pct": {
      "running": 5.0,
      "locked_rotor": 15.0
    },
    "service_entrance_vd_load_a": 1600,
    "branch_circuits_inheriting_upstream_budget": 24,
    "branch_circuits_inheriting_detail": {
      "branch circuits B-01..B-18": 18,
      "feeders treated as branch circuits for VD (F-04, F-08, F-09, F-11, F-12, F-13)": 6,
      "208 V branch circuits inheriting through a transformer without reset (B-01..B-10 via K-13, B-16..B-18 via DP-3 transformer section)": 13
    },
    "branch_budget_by_panel_pct": {
      "LP-1 (B-01..B-10)": 2.252,
      "MCC-1 (B-11..B-15)": 3.0,
      "DP-3 (B-16..B-18)": 2.419,
      "DP-2 (F-08, F-09, F-13)": 3.0,
      "MSB-1 (F-04, F-11, F-12)": 3.0
    }
  },
  "cost": {
    "conductor_usd": 93637.18,
    "conductor_gross_usd": 99614.02,
    "campus_quantity_break_usd": -5976.84,
    "termination_usd": 9671.7,
    "raceway_usd": 47715.6,
    "material_usd": 97239.11,
    "labor_usd": 53785.37,
    "total_usd": 151024.48,
    "total_conductor_length_ft": 40888.0
  },
  "duct_assignment": {
    "SE-1": [
      "D1",
      "D2",
      "D5",
      "D6",
      "D9",
      "D10"
    ],
    "F-10": [
      "D4",
      "D8"
    ],
    "F-05": [
      "E1",
      "E2",
      "E3"
    ]
  },
  "duct_bank_db1_ducts_available": 10,
  "duct_bank_db1_ducts_available_to_SE-1": 8,
  "duct_bank_db1_ducts_used_by_SE-1": 6,
  "duct_bank_db1_ducts_reserved": [
    "D11",
    "D12"
  ],
  "duct_bank_db1_ducts_left_empty": [
    "D3",
    "D7"
  ],
  "mutual_heating_rise_k": 31.09,
  "mutual_heating_rise_by_duct_k": {
    "D1": 25.64,
    "D2": 27.08,
    "D4": 21.34,
    "D5": 29.62,
    "D6": 31.09,
    "D8": 23.53,
    "D9": 27.88,
    "D10": 29.03
  },
  "mutual_heating_rise_db2_k": 1.54,
  "standardised_sizes_larger_than_1awg": [
    "4/0",
    "300 kcmil",
    "500 kcmil",
    "600 kcmil"
  ],
  "ampacity_basis": "Engineering supervision, NFPA 70 (2023) 310.14(B); Cascadia Eng. Data Sec. 4 heat balance (raceway, free air/tray) and EDS-26 5.3 Neher-McGrath (duct banks); limited per EDS-26 5.5"
}
```
# Design basis - low-voltage wire schedule, sheet E-621, project P-4210

Engineer of record narrative for the conductor package of Building 4210 (and the Building 4212 shop fed from it). The schedule itself is `wire_schedule.csv` / sheet E-621; the parameters are in `calc_book.xlsx`; the criteria log is `constraint_register.xlsx`.

## 1. Codes of record, adopting document, order of precedence

The codes of record were fixed at the start of design (14 July 2025) and are listed on sheet G-001:

* **NFPA 70, National Electrical Code, 2023 edition** - the edition in effect at the start of design (UFC 3-501-01 1-9: the issue in effect when design started applies).
* **International Building Code, 2024 edition**, as adopted and modified by UFC 1-200-01.
* The adopting document is **UFC 1-200-01 DoD Building Code** (1 September 2022, Change 4 of 17 December 2024). Its 1-6.1 adopts the 2024 IBC; its 1-6.2 directs every IBC reference to NFPA 70 to **UFC 3-501-01**, which cites NFPA 70. UFC 3-501-01 (27 November 2024) and UFC 3-520-01 (16 January 2025) add the Department's requirements, and the installation standard **EDS-26 Rev 4** (12 June 2026) adds the installation's. Energy criteria are UFC 1-200-02 (ASHRAE 90.1).
* **Order of precedence:** where two of these documents set different limits for the same thing, the **most restrictive requirement governs** (G-001; EDS-26 1.1); where EDS-26 is silent the UFC governs.
* Superseded documents retained for reference only were **not used**: EDS-26 Rev 2 (its 7-size limit, 4-set limit, 5 ft allowance, 20 C earth, 12 W/m2K film and 2 %/3 % connected-load drop rule are void) and E-601 Rev A (old loads and device ratings). The Meridian datasheet is not the basis of design (Section 26 05 19 1.3) and none of its ampacities were used; all cable data are Cascadia Wire Engineering Data Section 4, issue 2026-1.

Conflicts resolved: (a) the UFC 3-520-01 3-6.3.1 60/75 C convention is applied by the rating of the device (EDS-26 5.5) and further limited by the listed lug rating, so F-07 is held to 60 C because LP-1 has 60 C lugs although its device is 800 A; (b) the M-501-C ambients are used with the 25 C floor of UFC 3-520-01 3-6.3.2 (never binding); (c) the geotechnical native-soil design value 0.95 K.m/W was rejected in favour of the 0.60 K.m/W thermal backfill that actually surrounds the encasements (GEO-4210-T 2.2), and the logged ground temperatures were rejected in favour of the EDS-26 5.3.2 method (GEO-4210-T 2.4); (d) the voltage-drop limits are the mandatory UFC 3-501-01 limits (EDS-26 5.6), not the advisory NFPA 70 informational notes and not the superseded Rev 2 split.

## 2. Environmental parameters and provenance

| Parameter | Value | Provenance |
|---|---|---|
| Outdoor design dry-bulb | 42 C | Highest DLY-TMAX-NORMAL in the NOAA 1991-2020 normals for USW00003145 (106.8 F = 41.56 C), rounded up (EDS-26 5.4) |
| Roof ambient (tray CT-R1) | 46 C | Outdoor design dry-bulb + 4 K (EDS-26 5.4); M-501-C states the same 46 C for information |
| Earth ambient at duct-bank depth | 27.45 C | Annual mean of the 366 DLY-TAVG-NORMAL values (76.00 F = 24.45 C) + 3 K (EDS-26 5.3.2) |
| Earth (backfill) thermal resistivity | 0.60 K.m/W | GEO-4210-T 2.2 - thermal backfill surrounds both duct banks; native 0.95 K.m/W rejected |
| Encasement concrete | 0.55 K.m/W | GEO-4210-T 2.3 |
| Solar irradiance / absorptivity / film | 1030 W/m2, 0.6, 14.0 W/m2K | EDS-26 5.4 (solar rise 14.05 K, independent of diameter) |
| Interior ambients | 40 C ceiling cavity (all E-611/E-612/E-616 circuits incl. F-09), 45 C for F-01, F-03 and B-11..B-15, 40 C Building 4212 shop | M-501-C table and notes 1 and 3 |
| Load factor | 100 percent | UFC 3-501-01 3-2.3.3, applied to every duct-bank circuit (EDS-26 5.3) |
| Termination allowance | 8 ft each end | EDS-26 4.2.4 |

Lengths are measured on the E-611/E-612/E-613/E-615/E-616 routing polylines at right angles (no diagonal is drawn), plus the E-618 vertical run, plus 16 ft, rounded up (EDS-26 4.2.4; UFC 3-520-01 3-6.3.2).

## 3. Load basis and ampacity method

* Feeders to distribution equipment (F-01, F-02, F-05, F-10): not less than 125 % of the continuous load and never less than the device (EDS-26 2.1) - the device governs in each case (600/400/400/600 A).
* Lighting, receptacle and hard-wired appliance branch circuits: not less than the branch device (EDS-26 2.1).
* Motor, A/C, ASD, elevator, fire-pump and transformer circuits: 125 % of FLA / RLA / drive input / transformer rated current, the device is not a floor (EDS-26 2.1.1): e.g. F-06 = 1.25 x 270.6 = 338.3 A, F-07 = 1.25 x 624.5 = 780.7 A, F-04/F-12 = 310 A, F-03 = 120 A.
* Ampacity basis: calculated under engineering supervision (NFPA 70 2023, 310.14(B); EDS-26 5.1) - raceway: Cascadia raceway table 90 C column x k_a = sqrt((90-Ta)/60) x k_g (k_g = 1, every set in its own conduit with 3 or 2 current-carrying conductors); tray: EDS-26 5.4 heat balance with solar gain and k_t = 1 + 0.06(N-3), N = 18; duct bank: EDS-26 5.3 Neher-McGrath with image-method mutual heating at operating current. Every value is then capped by the termination-temperature table value (EDS-26 5.5).
* Termination temperature: 60 C for devices of 100 A and below, 75 C above, lowered to the listed lug rating (LP-1, WH-1, DW-1, SEC-1, lighting and receptacle loads are 60 C).

## 4. Service-entrance sizing decision

SE-1 runs from the T-1 secondary lugs to MSB-1 in duct bank DB-1. Per UFC 3-501-01 3-2.3.3 and EDS-26 2.2 the conductors are sized for a continuous current not less than the **2000 A main-bus ampacity** of MSB-1, not the 1600 A main device. The terminals of T-1 and MSB-1 accept six conductors per phase of at most 600 kcmil and EDS-26 3.4.4 limits parallel sets to six, so the service is **6 sets of CU 500 kcmil XHHW-2** (333.3 A required per set; Neher-McGrath ampacity 348.1 A per set in its worst duct with mutual heating at 100 % load factor; 75 C raceway-table limit 403 A). Aluminium 600 kcmil (the largest the lugs take) reaches only 272-288 A per set in this bank because of mutual heating, and CU 400 kcmil reaches at most 332 A, so neither carries 2000 A in six sets. Each SE-1 duct carries a 4/0 copper conductor sized from NFPA 70 Table 250.122 on the 1600 A main device (EDS-26 5.7). For voltage drop the 1600 A device rating was used (UFC 3-501-01 3-2.7.4.3.1 reading, accepted by EDS-26 2.3, stated on the schedule): SE-1 drop = 1.043 %.

## 5. Voltage-drop budget allocation

The calculation starts at the **T-1 secondary lugs**, the point of government ownership (WRPU-2026-0412; UFC 3-501-01 3-2.7.4.2), at nominal 480 V with taps not credited (3-2.7.4.1). Limits (UFC 3-501-01 3-2.7.1, mandatory per EDS-26 5.6): feeders and service conductors **3 % cumulative** at the end of each feeder chain, branch circuits **3 %** on their own, **5 % total** at the load; motor, A/C, ASD and elevator feeders are branch circuits for voltage drop (3-2.7.4.3.2 b-e); the fire pump is held instead to 5 % running / 15 % locked rotor at the controller from the same start point (EDS-26 4.6.3). Loads are those of 3-2.7.4.3 by class: device rating for feeders (and 1600 A for SE-1), K-13 nominal output 624.5 A on F-07 and 624.5 x 208/480 x 1.06 = 286.9 A on F-06, motor FLA, RLA, drive input, elevator FLA, total connected lighting and appliance load, and 80 % of 20 A (16 A) for receptacles. Drop = k I L (R cos phi + X sin phi)/sets with R at 75 C and X for steel conduit inside, PVC in duct bank and tray (EDS-26 5.6).

**No reset at the low-voltage transformer:** K-13 (480-208 V) and the DP-3 transformer section stay below 1000 V, so the count continues (3-2.7); the transformer itself is taken as zero drop and its secondary starts at the primary percentage (3-2.7.4.5.3).

Allocation (cumulative at the end of each feeder chain):

| Chain | Cumulative drop | Downstream allowance |
|---|---|---|
| T-1 - MSB-1 (SE-1) | 1.043 % | first draw on every path |
| MSB-1 - MCC-1 (F-01) | 2.575 % | B-11..B-15 keep their full 3 % (worst total 3.512 %) |
| MSB-1 - DP-2 (F-02) | 1.407 % | F-08, F-09, F-13 keep 3 % |
| DP-2 - K-13 (F-06) | 1.546 % | - |
| K-13 - LP-1 (F-07) | 2.748 % | B-01..B-10 limited to 2.252 % each by the 5 % total |
| MSB-1 - DP-3 (F-05) | 2.581 % | B-16..B-18 limited to 2.419 % |
| MSB-1 - ATS-1 (F-10) | 2.777 % | end of the scope |

The budget was allocated by cost: the feeders were allowed to spend most of the 3 % where the branch circuits downstream were cheap to upsize, and were held back where a branch circuit could not be upsized. Two branch circuits fix the budget: **B-09** (DW-1, 60 A, #4 = the largest conductor its terminal accepts, own drop 2.09 %) caps LP-1 at 2.91 %, and **B-17** (CMP-1, #6 = its terminal maximum, own drop 2.35 %) caps DP-3 at 2.65 %. F-05 (716 ft) is therefore sized for voltage drop (3 sets AL 600 kcmil, 1.54 %), while F-07 at 60 C needs 3 x AL 500 kcmil for ampacity anyway and leaves LP-1 at 2.75 %. The **24 branch circuits** (B-01..B-18 and the six feeders treated as branch circuits, F-04, F-08, F-09, F-11, F-12, F-13) all inherit the drop spent upstream of their panel; the ten LP-1 circuits inherit 2.75 % and are upsized to #8/#6 where needed; the fire pump inherits SE-1 (total 1.34 % running, 2.71 % locked rotor).

## 6. Duct-bank assignment and thermal consequence

DB-1 (service duct bank, E-619) has 12 five-inch EPC-40 ducts at 9 in centres; **D11 (owner reserve) and D12 (existing site-lighting feeder) are reserved**, so **10 ducts (D1-D10) were available** to SE-1 and F-10, one three-phase set per duct (EDS-26 6.2; Section 26 05 33 3.2). F-10 needs two (ATS-1 accepts two 500 kcmil per phase), so **8 ducts were available to SE-1**, which uses six - the most its terminals and EDS-26 3.4.4 allow - leaving two empty:

* SE-1: D1, D2, D5, D6, D9, D10
* F-10: D4, D8
* empty: D3, D7; reserved D11, D12 carry no load (EDS-26 5.3.4).

The assignment was chosen by evaluating every placement of the 6 + 2 sets in the 10 available ducts with the EDS-26 5.3 model and keeping the one that maximises the smaller of the two ampacity margins: SE-1 fills the two west columns (D1, D2, D5, D6, D9, D10), F-10 takes the top and middle of the east column (D4, D8), and the two empty ducts D3 and D7 separate the circuits. Mutual heating is computed at operating currents (SE-1 1732/6 = 288.7 A per set, F-10 432/2 = 216 A per set), load factor 1.0 and the 0.60 K.m/W backfill; the worst duct (D6) rises **31.1 K** (max), of which SE-1's own ducts contribute up to 24.7 K - about half of the 62.6 K available between the 90 C conductor and the 27.45 C earth. The thermal consequence for the other circuit in the bank is direct: alone in the bank F-10 in AL 500 kcmil would rate 368 A per set (capped at 314 A by the 75 C table), but surrounded by the six loaded SE-1 ducts it rates 302.2 A per set against the 300 A it must carry, so F-10 is placed at the east edge, as far from the SE-1 group as the reserved ducts allow; conversely F-10 adds about 6 K to the SE-1 ducts, and with SE-1's own heating this rules out CU 400 kcmil (at most 321-332 A per set) and aluminium 600 kcmil (272-288 A) for the service. DB-2 carries only F-05 (E1, E2, E3; E4 is reserved for communications) and its own mutual heating is 1.5 K. Duct fill is far below 40 %.

## 7. Material and standardisation decisions

* Copper for every conductor #6 and smaller (UFC 3-520-01 3-6.3.1) and for every EGC (EDS-26 3.2, copper THHN/THWN-2 green); aluminium 1350 XHHW-2 used as the value-engineering option (EDS-26 3.2; all terminations listed AL/CU) where it was cheaper at equivalent ampacity: F-01, F-04, F-05, F-07, F-08, F-09, F-10, F-12, F-13.
* Copper kept where it is cheaper installed - SE-1 (aluminium cannot carry the service in six sets), F-02 and F-06 (one CU 500 kcmil set and one conduit instead of two aluminium sets), and all motor branch circuits, where the smaller copper conductor keeps the smaller reference conduit.
* **Size standardisation (EDS-26 3.4.2):** only **four** sizes larger than #1 are used - 4/0, 300, 500 and 600 kcmil (five size/material combinations: AL 4/0, AL 300, AL 500, AL 600, CU 500). This is a project decision rather than circuit economics: F-06 would be cheaper in 400 kcmil and F-04/F-08/F-12/F-13 in 3/0 at fewer tray conductors, but the optimum over every admissible set of at most five sizes is this four-size set, which also keeps the size/material combinations at five; the cheapest design using five sizes would save only about 0.2 % and the unrestricted (six-size) optimum about 0.4 %.
* Not more than six sets and no paralleled conductor below 1/0 (EDS-26 3.4.4); each set in its own conduit or duct with its own EGC (Section 26 05 19 3.1). No conductor exceeds the largest size its terminals accept and no circuit has more sets than terminals (EDS-26 3.3), so no termination size reduction is used.
* EGC: NFPA 70 Table 250.122 on the device rating, increased in circular-mil ratio where the phase conductor was increased for voltage drop (EDS-26 5.7; UFC 3-501-01 3-2.7) - e.g. F-05 (3 sets AL 600 kcmil against an ampacity-only AL 2/0) carries a 250 kcmil copper EGC per duct, and the LP-1 and DP-3 20 A circuits carry EGCs equal to their upsized phase conductors.
* Neutral conductors are not part of this conductor package: every in-scope single-phase load is 208 V two-wire and no 120 V line-to-neutral circuit is in scope (EDS-26 5.2), so only phase conductors are counted as current carrying.
* Raceway: rigid steel conduit at the Cascadia reference trade size of the phase conductor (EDS-26 6.1), checked for 40 % fill and for the 2.8-3.2 jam ratio; no increase was needed. Tray CT-R1 carries F-04 and F-12 (2 sets each) and F-08, F-13 (1 set each): N = 18 current-carrying conductors, sum of diameters 12.21 in including the EGCs against the 16.2 in limit (EDS-26 6.3.2).

## 8. Cost ledger - material and labour

Priced at the Cascadia 2026 installed unit prices and the P-4210 unit price book (EDS-26 8), material and labour carried separately; duct banks and the tray are existing and carry no cost; conduit is priced per set on the circuit length.

| Item | Material USD | Labour USD | Installed USD |
|---|---|---|---|
| Phase conductors (XHHW-2) | 60617.23 | 20332.23 | 80949.46 |
| Equipment grounding conductors (copper) | 14527.01 | 4137.55 | 18664.56 |
| Campus quantity break (-6 % of all conductor, total 40888 ft >= 38,000 ft) | -4508.65 | -1468.19 | -5976.84 |
| Terminations (per set per end) | 5140.92 | 4530.78 | 9671.70 |
| Rigid steel conduit | 21462.60 | 26253.00 | 47715.60 |
| **Total** | **97239.11** | **53785.37** | **151024.48** |

Conductor (phase + EGC) net of the campus break: 93637.18 USD (gross 99614.02, break -5976.84); terminations 9671.70 USD; raceway 47715.60 USD. Installed total **151024.48 USD** = material 97239.11 + labour 53785.37; this equals the `Total` row of the cost_ledger sheet and `total_usd` on the front sheet.

## 9. Circuit summary

| Circuit | Selection | EGC | Raceway / ducts | Corrected A/set | Drop % | At load % |
|---|---|---|---|---|---|---|
| B-01 | 1 x CU 8 | 8 | 1 in RMC | 40.0 | 1.885 | 4.633 |
| B-02 | 1 x CU 6 | 6 | 1.25 in RMC | 54.0 | 1.647 | 4.395 |
| B-03 | 1 x CU 8 | 8 | 1 in RMC | 40.0 | 2.002 | 4.750 |
| B-04 | 1 x CU 8 | 8 | 1 in RMC | 40.0 | 1.652 | 4.400 |
| B-05 | 1 x CU 8 | 8 | 1 in RMC | 40.0 | 1.675 | 4.423 |
| B-06 | 1 x CU 6 | 6 | 1.25 in RMC | 54.0 | 2.094 | 4.842 |
| B-07 | 1 x CU 6 | 8 | 1.25 in RMC | 54.0 | 1.930 | 4.678 |
| B-08 | 1 x CU 8 | 4 | 1 in RMC | 40.0 | 1.634 | 4.382 |
| B-09 | 1 x CU 4 | 10 | 1.5 in RMC | 74.0 | 2.085 | 4.833 |
| B-10 | 1 x CU 12 | 12 | 0.75 in RMC | 22.0 | 1.619 | 4.367 |
| B-11 | 1 x CU 4 | 6 | 1.5 in RMC | 85.7 | 0.526 | 3.101 |
| B-12 | 1 x CU 4 | 6 | 1.5 in RMC | 85.7 | 0.645 | 3.220 |
| B-13 | 1 x CU 6 | 8 | 1.25 in RMC | 54.0 | 0.303 | 2.878 |
| B-14 | 1 x CU 6 | 8 | 1.25 in RMC | 54.0 | 0.366 | 2.941 |
| B-15 | 1 x CU 4 | 8 | 1.5 in RMC | 74.0 | 0.937 | 3.512 |
| B-16 | 1 x CU 2 | 8 | 2 in RMC | 102.0 | 1.639 | 4.220 |
| B-17 | 1 x CU 6 | 10 | 1.25 in RMC | 54.0 | 2.347 | 4.928 |
| B-18 | 1 x CU 8 | 8 | 1 in RMC | 40.0 | 1.966 | 4.547 |
| F-01 | 2 x AL 500 kcmil | 1 | 4 in RMC | 306.6 | 1.532 | 2.575 |
| F-02 | 1 x CU 500 kcmil | 3 | 4 in RMC | 403.0 | 0.363 | 1.407 |
| F-03 | 1 x CU 1 | 6 | 2 in RMC | 134.2 | 0.295 | 1.339 |
| F-04 | 2 x AL 4/0 | 3 | tray CT-R1 | 171.9 | 1.247 | 2.290 |
| F-05 | 3 x AL 600 kcmil | 250 kcmil | E1, E2, E3 | 336.0 | 1.538 | 2.581 |
| F-06 | 1 x CU 500 kcmil | 2 | 4 in RMC | 403.0 | 0.140 | 1.546 |
| F-07 | 3 x AL 500 kcmil | 1/0 | 4 in RMC | 263.0 | 1.201 | 2.748 |
| F-08 | 1 x AL 4/0 | 6 | tray CT-R1 | 171.9 | 0.661 | 2.067 |
| F-09 | 1 x AL 300 kcmil | 4 | 3 in RMC | 230.0 | 0.969 | 2.375 |
| F-10 | 2 x AL 500 kcmil | 1 | D4, D8 | 302.2 | 1.734 | 2.777 |
| F-11 | 1 x CU 3 | 6 | 1.5 in RMC | 99.0 | 1.162 | 2.206 |
| F-12 | 2 x AL 4/0 | 3 | tray CT-R1 | 171.9 | 1.577 | 2.620 |
| F-13 | 1 x AL 4/0 | 6 | tray CT-R1 | 171.9 | 1.113 | 2.519 |
| SE-1 | 6 x CU 500 kcmil | 4/0 | D1, D2, D5, D6, D9, D10 | 348.1 | 1.043 | 1.043 |
