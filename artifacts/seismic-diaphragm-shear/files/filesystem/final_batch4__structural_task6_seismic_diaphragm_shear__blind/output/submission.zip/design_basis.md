# Building B - seismic diaphragm and shear wall design basis

Design format: LRFD

All loads in this package are LRFD strength-level seismic load effects (E = rho QE with rho = 1.0; collectors Omega0 QE) and all capacities are phi x nominal values of the referenced standards (deck phi = 0.60 per AISI S310 / BDS-2026-DT; connectors, tie-downs and anchors phi = 0.75 per RPC-CAT-2026; steel members phi = 0.90). Units: ft, kips, plf.

## 1. Seismic basis

* Governing standards: 2024 IBC as adopted by Montana, ASCE/SEI 7-22, ACI 318-19, AISI S310 (SDC-02 Rev 2 Sec. 1).
* Risk Category III, Ie = 1.25 (SDC-02 Sec. 2; OBD-CDDC-B Rev 4 Sec. 1.4 - county 911 emergency communications tenant; ASCE 7-22 Sec. 11.5.1 / Table 1.5-2).
* Site Class D (GEO-2026-071 Sec. 4, Vs,100 = 905 ft/s). SDS = 0.44 g, SD1 = 0.24 g from the USGS ASCE 7-22 web-service output for RC III / Site Class D held in 30_seismic (SDC-02 Sec. 3).
* SDC: SDS = 0.44 gives C, SD1 = 0.24 >= 0.20 gives D; the more severe governs: **SDC D** (ASCE 7-22 Sec. 11.6).
* hn = 28 ft (top of deck, A-101 Rev 3 note 2). Ta = 0.02 x 28^0.75 = 0.243 s (Table 12.8-2). Cs = SDS/(R/Ie) = 0.44/(4/1.25) = 0.1375; Cs,max = 0.308; Cs,min = 0.0242.
* Effective seismic weight (Sec. 12.7.2): roof 20 psf x 39,200 sf net = 784.0 k; RTUs 45.0 k; walls 1,716.1 plf (lever action, below) x 840 ft = 1,441.5 k; **W = 2270.5 k, V = 312.2 k** (future mass case W = 2286.5 k, V = 314.4 k). One storey: Fx = V at the roof.
* Wall weight tributary to the roof with the parapet lever action (SDC-02 Sec. 6, FEMA P-2192-V1 Sec. 7.6.1 Step 1): 100 psf x 31 x (31/2)/28 = 1,716.1 plf, i.e. tributary height 17.161 ft. Parapet transfer (wall above deck delivered to roof) = 100 x 3 x (28 + 1.5)/28 = 316.1 plf.
* Redundancy rho = 1.0 (Sec. 12.3.4.2(b): regular in plan, more than two bays of perimeter wall on every side; diaphragm, collectors and anchorage take rho = 1.0 per 12.3.4.1).

## 2. Seismic force-resisting system

**Selected: intermediate precast shear walls, bearing wall system - UFC 3-301-01 Change 6 Table 3-1 row A.6 (replacement for ASCE 7-22 Table 12.2-1, same coefficients for the precast rows; SDC-02 Sec. 1 and 4): R = 4, Omega0 = 2-1/2 (2.0 for collectors, footnote b, flexible untopped steel deck diaphragm per Sec. 12.3.1.1), Cd = 4.** Permitted in SDC D up to hn = 40 ft (45 ft single storey storage per footnote i); hn = 28 ft. Detailing: ACI 318-19 Sec. 18.5 (18.2.1.6) and IBC 1905.3.

Why it is the cost-efficient choice:
* Ordinary precast shear walls (row A.7, R = 3) are **not permitted** in SDC D.
* Special precast walls (row A.1, R = 5) would cut seismic forces by 20 % but carry a detailing premium of USD 4,120/panel against USD 1,850/panel (PROC-114): +USD 183,870 on the 81 erected panels, and every joint connector would have to be the ACI 318-19 18.5.2 / ITG-5.2 qualified RPC-60D (JC3, USD 1,240 each). The force reduction saves at most a few thousand dollars of deck attachment, so special walls cost far more in total.
* Within the intermediate system the panels are detailed as **isolated panel piers (JC0, no vertical joint connectors)**. In the DAP-2 Stage A model (verified against VP-1: k_seg 1,279.4 kip/in, joint shears 0.2630/0.2527, panel 1 base moment 88.91 kip-in, axial 0.2630) coupling the panels raises the end-panel base moment and adds the coupling axial force to the tie-down, so connectors would both cost money and increase the tie-down demand. The isolated-pier solution needs only one base tie-down per panel.

## 3. As-built geometry

The scan (CDDC-SV-2026-041) was registered to the building grid on the four >240-intensity spheres CP-1..CP-4 (rotation -1.742 deg about Z, translation 31.125/-18.214/-0.412 ft, residuals < 0.001 ft). Openings were extracted from gaps in the wall-face points:

| wall | openings reaching foundation (split segments) | louvers (spandrel, sill 14 ft, head 24 ft) | segments (start-end, ft) |
|---|---|---|---|
| S | D-1 18-32, D-2 48-62, D-3 78-93.5, D-4 109.5-123.5, D-5 138-152, P-1 196-200 | - | S-A 0.0-18.0, S-B 32.0-48.0, S-C 62.0-78.0, S-D 93.5-109.5, S-E 123.5-138.0, S-F 152.0-196.0, S-G 200.0-240.0 |
| N | P-2 24-28 | L-1 60-72, L-2 154-170 | N-A 0.0-24.0, N-B 28.0-240.0 |
| W | P-3 12-16, EY-1 66-110 | - | W-A 0.0-12.0, W-B 16.0-66.0, W-C 110.0-180.0 |
| E | D-6 72-86, P-4 150-154 | L-3 108-120 | E-A 0.0-72.0, E-B 86.0-150.0, E-C 154.0-180.0 |

Conflicts found and the reading taken:
* **risk category** - III (Ie = 1.25). Basis: SDC-02 Rev 2 Sec. 2 and OBD-CDDC-B Rev 4 Sec. 1.4 (911 emergency tenant); the RC II code block on the architectural cover sheet is superseded (SDC-02 Sec. 2); USGS RC III file used.
* **site class and ground motion** - Site Class D, SDS 0.44, SD1 0.24 (ASCE 7-22), SDC D. Basis: GEO-2026-071 Sec. 4 (Vs100 = 905 ft/s) and SDC-02 Sec. 3; GEO-2019-118 (Parcel 4B, ASCE 7-16, Site Class C, SDS 0.407/SD1 0.149, SDC C) and its 2019 USGS file do not apply to Building B.
* **south wall D3 D4 positions** - D-3 78.0-93.5 ft (15.5 ft clear); D-4 109.5-123.5 ft; pier D-4/D-5 = 123.5-138.0 ft (14.5 ft). Basis: RFI-041 (erected geometry accepted, design on scan + erection log), ERL-2026-08 and scan CDDC-SV-2026-041; PC-101 Rev 2 detailed dimensions (D-3 14 ft, pier 16 ft) not used.
* **louver L2** - L-2 154.0-170.0 ft, 16 ft wide, sill 14 ft, head 24 ft. Basis: PCS-014 N-12 shop ticket Rev B, ERL-2026-08, RFI-041 and scan; A-101/PC-101 detailed 12 ft at 156-168 superseded.
* **west opening EY1** - EY-1 66.0-110.0 ft, 44 ft wide, 20 ft high. Basis: Field change FC-018 recorded in ERL-2026-08 (2026-06-24), RFI-041 and scan; PC-101/A-101 40 ft not used. EY-1 straddles Y = 90 ft so both DR-W1 and DR-W2 are required.
* **record vs erected geometry** - Erected geometry from scan registered on CP-1..CP-4 (rotation -1.742 deg, residual < 0.001 ft). Basis: PR-07 requires the semi-rigid model on the erected geometry; scan report Sec. 4: the scan is the record of the erected geometry.
* **footprint dimension** - Diaphragm 240.0 x 180.0 ft between inside faces of panels on grids 1/9 and A/G. Basis: Scan control report Sec. 3 (grid origin at inside face) and the scan (wall faces at X = 0/240, Y = 0/180); A-101 note 1 "out-to-out" wording not used.
* **diaphragm design method** - ASCE 7-22 Sections 12.10.1 and 12.10.2. Basis: SDC-02 Sec. 5; 12.10.3 and 12.10.4 not used (FEMA P-2192 Sec. 7.6.2/7.6.3 alternative methods rejected); the 12.10 exception for precast diaphragms does not apply to steel deck.
* **collector overstrength** - Omega0 = 2.0. Basis: UFC 3-301-01 Table 3-1 footnote b / SDC-02 Sec. 4: tabulated 2.5 reduced by 0.5 for the flexible (untopped steel deck) diaphragm.
* **idealisation** - envelope of flexible, rigid and semi-rigid (DAP-2). Basis: PR-07 Comment 7 rejects flexible-only design although Sec. 12.3.1.1 permits it; SDC-02 Sec. 10.
* **wall anchorage minimum** - Fp = 0.2 ka Ie Wp = 0.50 Wp governs over 0.4 SDS ka Ie Wp = 0.44 Wp. Basis: ASCE 7-22 Sec. 12.11.2.1; ka = 2.0 (cap) with Lf per UFC Fig. 3-1; Wp includes parapet lever action (SDC-02 Sec. 6).
* **construction stage load** - 0.5 x permanent seismic load; deck X <= 180 ft only. Basis: ERC-07 Sec. 3 and 4 (cases S11, S12).
* **superseded documents** - not used. Basis: T-2026-118: documents in 90_archive (A-101 Rev 1, SM-2019-04 Building A, WM-2026-09) are record only; A-101 Rev 3 governs (RTU-5, RTU-6 added).
* Panel S-10 (6 ft ticket) cannot fit the 14.5 ft erected pier with S-09 (10 ft); the pier is modelled as 10 + 4.5 ft per the scan. W-08 is taken as cut to 6 ft by FC-018 (W segment 110-180 ft = 6 + 6x10 + 4). 81 erected panels (19 S, 28 N, 15 W, 19 E) are used for quantities.
* Louver pieces are reported as "spandrel" pieces of the continuous segment; per DAP-2 Sec. 3 the panels at a louver keep their length and their flexural and shear rigidities are factored by the solid fraction 18/28.

## 4. Analysis

Analysis follows DAP-2 Rev 1 exactly as required by SDC-02 Sec. 10 and PR-07 Comment 7:
* Stage A: each segment of panels as cantilevers (h = 28 ft to the diaphragm, Ec = 57,000 sqrt(6000) psi, Gc = Ec/2.4, Av = 5/6 Ag, I = 0.5 Ig, louver panels x 18/28) tied by the roof chord; k_seg and per-kip joint shears, base moments and axial forces recovered; tie-down = Mbase/(0.8 L) + axial. Verified against VP-1.
* Stage B: 10 ft Q4 plane-stress mesh, 40 elements inside RO-1/RO-2 removed, D = diag(1740, 1740, G') kip/in with G' per zone pattern (BDS-2026-DT Table 4), chord/collector bars EA (E = 29,000 ksi), segment springs distributed by tributary length. Loads: Fpx/wpx = 0.1375 times roof DL over net deck area, RTUs at their positions and the perpendicular walls (1,716 plf); parallel walls carry their own inertia into their own springs. Accidental torsion 5 % (9 ft for X, 12 ft for Y) as a mass-proportional rotational field, Ax from the rigid model (capped at 3.0).
* Envelope of flexible (simple beam between the resisting wall lines, unit shear = V/net depth, chord = M/net depth), rigid (membrane x 10^7) and semi-rigid. Zone design shear = largest section mean (DAP-2 6.1). 100/30 cases add 0.30 x the companion case (DAP-2 6.4).
* Cases S01-S12 of SDC-02 Sec. 8 plus 24 sensitivity cases (both eccentricity signs, both mass cases, with and without 100/30, both erection directions) are enveloped for design. Construction stage S11/S12: 0.5 x seismic, deck only over X <= 180 ft (ERC-07 Sec. 3-4); in S12 the east wall line has no diaphragm support so the rigid-model ratio dmax/davg = 2.0 and Ax = 2.78 is applied.

## 5. Diaphragm and wall forces

| direction | wpx (k) | Fpx/wpx | Fpx (k) | span (ft) | w_px (plf) |
|---|---|---|---|---|---|
| E-W (X) | 1446.8 | 0.1375 | 198.9 | 180 | 1105.2 |
| N-S (Y) | 1652.7 | 0.1375 | 227.2 | 240 | 946.9 |

Fpx bounds (Sec. 12.10.1.1): 0.2 SDS Ie wpx = 0.110 wpx <= 0.1375 wpx <= 0.4 SDS Ie wpx = 0.220 wpx - Eq. 12.10-1 governs.

Wall line forces F_x (kips, LRFD envelope) and maximum zone unit shear:

| case | dir | S | N | W | E | Ax | max zone shear (plf) | semi-rigid Cd delta/Ie (in) |
|---|---|---|---|---|---|---|---|---|
| S01 | X | 156.6 | 163.4 | 12.2 | 12.2 | 1.000 | 519 | 1.63 |
| S02 | X | 155.0 | 171.7 | 5.2 | 5.2 | 1.000 | 513 | 1.62 |
| S03 | Y | 6.7 | 6.7 | 155.6 | 167.5 | 1.000 | 804 | 2.99 |
| S04 | Y | 12.0 | 12.0 | 161.3 | 156.6 | 1.000 | 859 | 3.02 |
| S05 | X | 158.6 | 165.4 | 58.8 | 62.4 | 1.000 | 727 | 1.63 |
| S06 | Y | 58.6 | 63.6 | 162.9 | 158.1 | 1.000 | 986 | 3.02 |
| S07 | X | 157.3 | 164.7 | 12.1 | 12.1 | 1.000 | 524 | 1.65 |
| S08 | Y | 6.7 | 6.7 | 155.9 | 169.2 | 1.000 | 810 | 3.00 |
| S09 | X | 159.3 | 176.6 | 53.8 | 52.8 | 1.000 | 690 | 1.65 |
| S10 | Y | 58.4 | 63.6 | 163.2 | 160.1 | 1.000 | 995 | 3.03 |
| S11 | X | 56.1 | 53.3 | 0.0 | 0.0 | 1.267 | 244 | 0.81 |
| S12 | Y | 26.2 | 26.2 | 105.4 | 0.0 | 2.778 | 653 | 3.29 |

Deck attachment by zone (envelope zone shear vs phi Sn = 0.60 Sn):

| zone | pattern | demand (plf) | phi Sn (plf) | D/C |
|---|---|---|---|---|
| Z1 | P5 | 995 | 1101 | 0.90 |
| Z2 | P3 | 501 | 663 | 0.76 |
| Z3 | P3 | 473 | 663 | 0.71 |
| Z4 | P5 | 862 | 1101 | 0.78 |
| Z5 | P4 | 664 | 852 | 0.78 |
| Z6 | P3 | 449 | 663 | 0.68 |
| Z7 | P2 | 350 | 474 | 0.74 |
| Z8 | P4 | 776 | 852 | 0.91 |
| Z9 | P5 | 786 | 1101 | 0.71 |
| Z10 | P4 | 604 | 852 | 0.71 |
| Z11 | P4 | 658 | 852 | 0.77 |
| Z12 | P4 | 762 | 852 | 0.89 |

Maximum semi-rigid diaphragm deflection plus wall drift Cd delta/Ie = 3.29 in <= 4.0 in (SDC-02 Sec. 7) over S01-S12 and the final-stage sensitivity cases (S12 also checked with Ax = 1.0 if the unsupported east line is excluded from the Ax ratio: 3.66 in); maximum storey drift 0.31 in <= 0.015 hsx = 5.04 in (Table 12.12-1, RC III).

Chords, collectors and drag struts (design axial = max of chord force and Omega0 = 2.0 x collector force):

| line | member | demand (k) | phi Pn (k) |
|---|---|---|---|
| CH-S | C2 L6x4x1/2 continuous | 67.8 | 106.8 |
| CH-N | C2 L6x4x1/2 continuous | 57.3 | 106.8 |
| CH-W | C1 L4x4x3/8 continuous | 35.2 | 58.9 |
| CH-E | C1 L4x4x3/8 continuous | 29.6 | 58.9 |
| DR-S1 | C1 L4x4x3/8 continuous | 28.5 | 58.9 |
| DR-S2 | C1 L4x4x3/8 continuous | 39.6 | 58.9 |
| DR-N1 | C1 L4x4x3/8 continuous | 4.5 | 58.9 |
| DR-N2 | C1 L4x4x3/8 continuous | 3.1 | 58.9 |
| DR-W1 | C1 L4x4x3/8 continuous | 28.4 | 58.9 |
| DR-W2 | C1 L4x4x3/8 continuous | 28.5 | 58.9 |
| DR-E1 | C1 L4x4x3/8 continuous | 17.0 | 58.9 |
| DR-E2 | C1 L4x4x3/8 continuous | 4.6 | 58.9 |
| OP-1S | C1 L4x4x3/8 continuous | 3.9 | 58.9 |
| OP-1N | C1 L4x4x3/8 continuous | 4.9 | 58.9 |
| OP-1W | C1 L4x4x3/8 continuous | 3.2 | 58.9 |
| OP-1E | C1 L4x4x3/8 continuous | 3.3 | 58.9 |
| OP-2S | C1 L4x4x3/8 continuous | 6.3 | 58.9 |
| OP-2N | C1 L4x4x3/8 continuous | 6.5 | 58.9 |
| OP-2W | C1 L4x4x3/8 continuous | 4.3 | 58.9 |
| OP-2E | C1 L4x4x3/8 continuous | 4.4 | 58.9 |

All four perimeter chords and all eight roof-opening chords are provided (SDC-02 Sec. 5). Drag struts are continuous across every wall opening >= 12 ft: D-1..D-4 (DR-S1; D-4 109.5-123.5 crosses X = 120 so DR-S2 also), D-5 (DR-S2), L-1 (DR-N1), L-2 (DR-N2), EY-1 66-110 (crosses Y = 90: DR-W1 and DR-W2), D-6 (DR-E1), L-3 (DR-E2).

## 6. Wall anchorage and the parapet cantilever

* Wp = 1,716.1 plf per foot of wall (includes the 3 ft parapet lever action; parapet transfer 316.1 plf).
* ka = 1 + Lf/100 <= 2.0 (Eq. 12.11-2) with Lf per UFC 3-301-01 Figure 3-1: S/N walls Lf = 240 ft (ka 3.4 -> 2.0), W/E walls Lf = 180 ft (ka 2.8 -> 2.0).
* Fp = 0.4 SDS ka Ie Wp = 0.44 Wp is less than the minimum 0.2 ka Ie Wp = 0.50 Wp, so **Fp = 858.0 plf** (Sec. 12.11.2.1). Steel anchorage elements x 1.4 (Sec. 12.11.2.2.2) = 1,201.3 plf.
* S wall: WA2 @ 10 ft: demand 12.01 k/anchor <= phi Tn = 13.95 k (D/C 0.86). Subdiaphragm span 40 ft, depth 36 ft, L/d = 1.11 <= 2.5 (Sec. 12.11.2.2.1), continuous crossties on the girder lines X = 40, 80, ..., 200 ft (subdiaphragm chord on the joist line 36 ft from the wall; unit shear 858 x 40/2/36 = 477 plf <= phi Sn of the edge zones).
* N wall: WA2 @ 10 ft: demand 12.01 k/anchor <= phi Tn = 13.95 k (D/C 0.86). Subdiaphragm span 40 ft, depth 36 ft, L/d = 1.11 <= 2.5 (Sec. 12.11.2.2.1), continuous crossties on the girder lines X = 40, 80, ..., 200 ft (subdiaphragm chord on the joist line 36 ft from the wall; unit shear 858 x 40/2/36 = 477 plf <= phi Sn of the edge zones).
* W wall: WA2 @ 10 ft: demand 12.01 k/anchor <= phi Tn = 13.95 k (D/C 0.86). Subdiaphragm span 6 ft, depth 6 ft, L/d = 1.00 <= 2.5 (Sec. 12.11.2.2.1), continuous crossties on the E-W joist lines at 6 ft o.c. (subdiaphragm unit shear 858 x 6/2/6 = 429 plf).
* E wall: WA2 @ 10 ft: demand 12.01 k/anchor <= phi Tn = 13.95 k (D/C 0.86). Subdiaphragm span 6 ft, depth 6 ft, L/d = 1.00 <= 2.5 (Sec. 12.11.2.2.1), continuous crossties on the E-W joist lines at 6 ft o.c. (subdiaphragm unit shear 858 x 6/2/6 = 429 plf).
* Erection: raking braces 12 kip each at 10 ft (ERC-07 Sec. 2 minimum 12 kip, maximum 20 ft; 29 CFR 1926.704(a)); braces removed only after the deck in that bay is fastened. Demand on the panels east of X = 180 ft that have no diaphragm support in S11/S12: 0.5 x 0.25 Wp (ka = 1.0) with Wp = 100 x 31^2/(2 x 20.67) = 2.32 k/ft -> 0.29 k/ft, 2.9 k per brace horizontal, 5.8 k along a 60-degree brace <= 12 k (D/C 0.48).

## 7. Governing constraint per wall line

* **S wall** - governing: panel base tie-down (BA2), D/C = 0.90 (envelope segment force incl. own-inertia share of the wall line); next: wall-to-diaphragm anchorage (WA2 @ 10 ft), D/C = 0.86. Joint connectors JC0 (isolated panel piers), base tie-down BA2 on every panel, anchors WA2 @ 10 ft.
* **N wall** - governing: wall-to-diaphragm anchorage (WA2 @ 10 ft), D/C = 0.86 (includes the 1.4 steel-element factor of Sec. 12.11.2.2.2; without it D/C = 0.62); next: panel base tie-down (BA2), D/C = 0.52. Joint connectors JC0 (isolated panel piers), base tie-down BA2 on every panel, anchors WA2 @ 10 ft.
* **W wall** - governing: wall-to-diaphragm anchorage (WA2 @ 10 ft), D/C = 0.86 (includes the 1.4 steel-element factor of Sec. 12.11.2.2.2; without it D/C = 0.62); next: panel base tie-down (BA2), D/C = 0.78. Joint connectors JC0 (isolated panel piers), base tie-down BA2 on every panel, anchors WA2 @ 10 ft.
* **E wall** - governing: wall-to-diaphragm anchorage (WA2 @ 10 ft), D/C = 0.86 (includes the 1.4 steel-element factor of Sec. 12.11.2.2.2; without it D/C = 0.62); next: panel base tie-down (BA2), D/C = 0.67. Joint connectors JC0 (isolated panel piers), base tie-down BA2 on every panel, anchors WA2 @ 10 ft.

## 8. Cost

| item | USD |
|---|---|
| deck attachment (net zone areas) | 74,875 |
| chords / collectors / drag struts | 27,312 |
| panel joint connectors | 0 |
| panel base tie-downs (81 panels) | 73,710 |
| wall-to-diaphragm anchors | 14,448 |
| SFRS detailing premium (81 panels x 1,850) | 149,850 |
| **total installed cost** | **340,195** |

Capital cap (PROC-114 Rev 2, OBD 5.6, SDC-02 Sec. 11): USD 395,000 -> margin USD 54,805 (86.1 % of cap used).

## 9. Alternatives rejected

* Ordinary precast shear walls (R = 3): not permitted in SDC D (UFC Table 3-1 A.7).
* Special precast shear walls (R = 5): +USD 183,870 SFRS premium plus JC3-only connectors; exceeds any force-reduction saving and approaches the cap.
* Panel joint connectors (JC1/JC2 in 1-4 per joint): add USD 385-610 per connector and, in the DAP-2 Stage A model, increase the end-panel base moment and tie-down force; isolated panel piers (JC0) chosen.
* ASCE 7-22 Sec. 12.10.4 alternative one-storey diaphragm design and Sec. 12.10.3: excluded by SDC-02 Sec. 5.
* Flexible-only (tributary) distribution: rejected by PR-07; envelope used.
* Designing on record (PC-101) dimensions: rejected per RFI-041 and PR-07 (erected geometry).
* Uniform deck pattern over the roof: zone-by-zone patterns sized to the enveloped section-mean shears and the 4.0 in deflection limit are cheaper.
* Wall anchors WA1 (joist seat anchor): with the 1.4 steel-element factor WA1 needs 4 ft spacing (USD 24/ft); WA2 at 10 ft (USD 17.2/ft) is cheaper. WA3 not needed.
* Omitting drag struts DR-* and relying on the chord lines alone: rejected - SDC-02 Sec. 5 requires a continuous drag strut across every opening >= 12 ft.
