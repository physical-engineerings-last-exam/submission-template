# Method note - frame extension over the occupied ground floor (TWP-09 rev C method package)

Issued with the construction sequence, the temporary-works design, the stability check sheet, the workspace and resource occupancy report and the constraint register, as the method package of TWP-09 rev C clause 1.2. Temporary works designer: R. Castellan, P.E. - Temporary Works Designer for the frame extension (qualified person, 29 CFR 1926.451(a)(6); qualified designer, 29 CFR 1926.703(b)(8)(i)). Drawings: TW-FE-001 rev C0 - formwork, shoring, reshoring, bracing and access scaffold drawings for the 3-lift frame extension, issued with this method package and held at the jobsite (29 CFR 1926.703(a)(2); TWP-09 rev C cl. 6.5).

## 1. Which document governs where the issued set disagrees with itself

* **TWP-09 revision C governs; revision B is superseded and not in force.** Where they disagree I worked to rev C: completion by day 250 (not 310), yard stock 3600 sf of soffit and 120 ft of scaffold face (not 4500 sf / 160 ft), 8 gangs (not 10), 10 crane hours per shift (not 12), reshoring at 8 ft centres (not 10 ft) and a 28-day full-strength age (not 21). Rev B allowed striking at the early-strike age without reshoring; rev C clause 6.3 does not, so every early strike in this programme is reshored. No rev B value or requirement is registered.
* **The issued activity list governs the programme** (`programme/activity_list.csv`, identical in logic to `programme/precedence_index.csv`: 294 activities, 308 links). The superseded baseline programme revision A is not in force: it carries 4-day SHOR durations (issued: 2 days) and omits the issued links that make each L3/L4 scaffold erection follow the strike of the scaffold of the level below. The issued durations and links are programmed exactly; I added only the TWP-09 clause 7.2 link (the level above in a zone starts after the level below has finished) and the strike-age lags.
* **The design schedules in `model/` are the takeoff.** The IFC exports (L1_HW_IFC.ifc, L3_HW_IFC.ifc) are partial and say nothing about how the frame is built; the column, slab, storey and zone schedules were used for every quantity, cross-checked against the zone work schedule (areas, faces, scaffold heights, clear heights, picks).
* **Where TWP-09 is more onerous than an adopted criterion, TWP-09 governs** (it stipulates the conditions of 29 CFR 1926.703(e)(1)(i), the 2000 psf mud-sill limit, the stair-core rule and Option (3) of 1926.1408). The Table A distance in `site/power_line_clearance_table_A.csv` agrees with 1926.1408 Table A (10 ft up to 50 kV).
* **MS-14 (facade replacement) is a different scope** and nothing in it (mast climbers, rope access, 8-day cycle) is applied or registered.

## 2. Striking and reshoring method adopted

Every slab is struck at its mix early-strike age and reshored as the original shores come out (TWP-09 6.3, 29 CFR 1926.703(b)(10), (e)(1)(i)): bands A-D (M40-PUMP) are struck no earlier than 7 days after the pour finishes, bands E-G (M50-HE) no earlier than 4 days. I measure the age from the pour **finish** day, not its start, which is a day conservative on the two-day bucket pours. The reshores are RS-16 at 8 ft centres both ways (posts = area/64, rounded up), installed on the strike day and removed no earlier than 28 days after the pour finish (TWP-09 6.4, 1926.703(e)(2)); `temporary_works.json` carries each install and remove day. Leaving the shores in for 28 days was rejected: it would hold 100 percent of the soffit in the yard for 33 days per zone-lift instead of 25 percent, and the 3600 sf yard and the one-stair-core rule could not then finish 42 zone-lifts by day 250. In the yard I count the full soffit from the SHOR start to the STRK finish and the 25 percent reshore share from the STRK start to the full-strength day inclusive, so the strike day is counted at 125 percent.

## 3. Programme

All 294 issued activities are programmed from day 0; the last activity finishes on day 195 and the last reshores come out on day 214, inside the day-250 completion date (TWP-09 3.3). The programme was built by a resource-constrained serial schedule over zone-lift templates (COL and SCAF, then SHOR-RBAR-POUR back to back, strike at the early-strike age, scaffold struck the next day) with the zone-lift order optimised on the price of each zone-lift (temporary works plus 4 units per day to its finish, TWP-09 10.2), so that as many zone-lifts as the yard allows finish close to the earliest day their own logic permits. It was then re-simulated day by day from the issued rows against every limit: crane hours, gangs, shoring and scaffold yard stock, laydown, stair cores shored, one zone-lift per zone and every issued link.

## 4. The constraint that governs each zone

Across the site the governing programme constraint is the **3600 sf shoring yard stock** (TWP-09 8.3): the 42 soffits need about 648,046 sf-days of shoring and reshoring (as I count it) against 900,000 available to day 250, so the yard sets the pace and the order. Zone by zone:

* **Z-A-N** - stair core (TWP-09 7.3, one core shored at a time) and the L2 protective deck (387.6 psf -> SP-16 at 3.5 ft); crane from CP-W at 78.6 ft. (L2 finishes day 14, L3 finishes day 38, L4 finishes day 59.)
* **Z-A-S** - L2 protective deck and medium-duty scaffold; crane from CP-C because CP-W is only 38.5 ft away, inside the 40 ft start of the chart. (L2 finishes day 62, L3 finishes day 81, L4 finishes day 95.)
* **Z-B-N** - largest soffit (1227 sf) so the yard stock governs its slot; 30 ft face so the scaffold stock, 5 bays and 3 tie columns; 2-day RBAR. (L2 finishes day 160, L3 finishes day 180, L4 finishes day 195.)
* **Z-B-S** - stair core (7.3) and the second-largest soffit (1177.8 sf) against the yard; 30 ft face. (L2 finishes day 146, L3 finishes day 172, L4 finishes day 192.)
* **Z-C-N** - L2 protective deck (5.4) sets the 3.5 ft shore grid; yard stock at L3/L4. (L2 finishes day 50, L3 finishes day 84, L4 finishes day 106.)
* **Z-C-S** - L2 protective deck (5.4); short crane radius (43 ft from CP-C). (L2 finishes day 47, L3 finishes day 61, L4 finishes day 83.)
* **Z-D-N** - heaviest pick, 30 in columns of 13,674 lb, governs the crane position (CP-C, 78.6 ft, 16,114 lb); SP-16 at 4.0 ft is 99.4 percent utilised. (L2 finishes day 14, L3 finishes day 37, L4 finishes day 93.)
* **Z-D-S** - heaviest pick 13,674 lb: CP-C is 38.5 ft away, off the chart, so CP-E at 76.8 ft (16,851 lb); SP-16 at 4.0 ft. (L2 finishes day 25, L3 finishes day 49, L4 finishes day 71.)
* **Z-E-N** - crane-and-bucket placement: 75 psf live load sets SP-16 at 3.5 ft, heavy-duty SF-5 scaffold, and the 8.29 crane-hour pour against the 10-hour shift. (L2 finishes day 24, L3 finishes day 122, L4 finishes day 134.)
* **Z-E-S** - stair core (7.3) plus the bucket pour and heavy-duty scaffold. (L2 finishes day 25, L3 finishes day 105, L4 finishes day 117.)
* **Z-F-N** - bucket pour crane hours and heavy-duty scaffold; crane from CP-E at 82.3 ft. (L2 finishes day 13, L3 finishes day 112, L4 finishes day 124.)
* **Z-F-S** - bucket pour crane hours and heavy-duty scaffold. (L2 finishes day 12, L3 finishes day 94, L4 finishes day 127.)
* **Z-G-N** - bucket pour (9.49 crane hours, the largest) against the shift; 24.03 ft face gives 4 heavy-duty bays. (L2 finishes day 147, L3 finishes day 166, L4 finishes day 182.)
* **Z-G-S** - bucket pour (9.10 crane hours) and 4 heavy-duty bays. (L2 finishes day 72, L3 finishes day 137, L4 finishes day 156.)

## 5. Temporary works design

* **Shoring** (TWP-09 6.1): design load = 312.6 psf slab + 10 psf formwork + 50 psf (pump) or 75 psf (bucket) + 15 psf deck where the ground floor below is occupied (L2 bands A-C). Required extension is lift base to soffit less 0.75 ft = 13.83-13.84 ft, which rules out SP-09 and SP-13; SP-16 (16 ft, 6000 lb) is the cheapest compliant post: 3.5 ft grid at 387.6/397.6 psf (4748/4871 lb per post) and 4.0 ft grid at 372.6 psf (5962 lb). Posts = area / spacing squared, rounded up.
* **Scaffold** (TWP-09 4, 5): SF-3 frames for light and medium duty, SF-5 for heavy duty (bands E-G), because the heavy platform needs 5 planks (47.5 in) for 4 x 1750 lb plus plank weight and that will not fit inside a 3 ft frame. Platforms are planked as fully as the 9.5 in plank module allows (3 planks on SF-3, 6 on SF-5, 1926.451(b)(1)), all wider than 18 in, all with capacity >= 4 x MIL + plank weight. SF-7 is rejected: its 10 ft bay equals the plank length, so planks could neither overlap 12 in over the bearers nor reach 6 in past them (1926.451(b)(4), (b)(7)). Frame lifts = height / 6.5 ft rounded up; ties at the horizontal member closest to the 4:1 height and then every 20 ft (SF-3) or 26 ft (SF-5), at each end and at <= 30 ft along the as-erected run; one rest platform on the L3 and L4 scaffolds (over 35 ft); guardrails at 42 in on the outer side and both ends of every platform level; front edge 12 in from the work; access by scaffold stair tower; mud sills 2x10 x 36 in under each base plate.
* **Lateral stability** (TWP-09 6.2): the 2 percent notional load governs every zone-lift (wind on the exposed area is about a tenth of it). XB-1 bracing at 4000 lb per braced bay is used unless an adjacent slab at the same level has been struck and is at least one clear day past its early-strike age before the shoring goes up, in which case that completed diaphragm is used (31 zone-lifts).
* **Crane and line** (TWP-09 9): standing position chosen per zone for the best capacity with the radius inside the chart (40-140 ft); Option (3) of 1926.1408 with the Table A distance of 10 ft for 34.5 kV; work zone demarcated at 140 ft, below the 145 ft limit (155 ft to the line less 10 ft).

## 6. Margins applied

* Crane: planned to 9.995 crane hours per day, under the 10-hour shift, so no day sits exactly on the limit.
* Stair cores: never two shored on one day, and at least one clear day between one core's strike and the next core's shoring.
* Yard: reshoring counted one day longer than needed (full-strength day inclusive) and overlapping the strike day; laydown counted through the pour finish day; scaffold face counted from erection start to strike finish.
* Strike: age measured from the pour finish; adjacent diaphragms only with one clear day beyond early-strike age.
* Scaffold: plank capacity includes plank self weight (light duty takes 3 planks, not 2); frame lifts rounded up; tie columns counted on the erected run; leg loads with own weight + 4 x MIL are at most 42 percent of the leg ultimate; mud-sill bearing at most 666 psf against 2000 psf.
* Shoring: post utilisation 79.1, 81.2, 99.4 percent of the SP-16 rating (the 99.4 percent case is the pump bands on the 4.0 ft grid, 5961.6 lb against 6000 lb); extension 2.16 ft spare.
* Crane capacity at least 18 percent over the heaviest pick (worst: the 13,674 lb 30 in columns of Z-D-N); demarcation 5 ft inside the Table A limit.

## 7. Attribution

The building geometry used here (storey elevations, column grid and sections, slab thickness, stair cores) is derived from the LivingBIM Dataset: As-designed and As-built Dataset for an Academic Building including BIM 3d models, Point Clouds, and Panoramic Images, DOI 10.5281/zenodo.17934615, licensed CC BY 4.0 (https://creativecommons.org/licenses/by/4.0/). The design schedules reproduced in this package are adapted from it; changes were made (zone breakdown and takeoff for this method package).
