# Design Basis - Building A2 Roof Diaphragm, Chords, Collectors and Precast Shear Walls for Wind

Northern Divide Data Campus, Building A2, Lewis and Clark County, Montana. Delegated lateral package prepared to EOR-NDDC-A2-S01 Structural Design Criteria Revision 2 (14 August 2026). **All loads, unit shears, reactions, chord forces and deflections in this package are ASD quantities (0.6W) per criteria 3.3.**

## 1. Values the design was built on

| item | value | source |
|---|---|---|
| Kzt | 1.19 | TS-2026-02 Topographic Wind Study s.4 (whole footprint, all azimuths); criteria 4.3 |
| Ke | 0.8670 | criteria 4.4, Ke = exp(-0.0000362 zg), zg = 3941.02 ft at site benchmark BM-2, ALTA-2025-77 s.1 |
| q_h_psf | 28.74 | criteria 4.2 at mean roof height h = 28.00 ft (Kz = 0.9681, Kzt = 1.19, Kd = 0.85, Ke = 0.8670, V = 115 mph per NDDC-AHJ-014 s.2); strength level |
| screen_wall_top_ft | 36.00 | SR-2026-118 s.5.2 (x = 96 to 168 ft, panels N108-N111) and the 2026 federated model; A-101/A-301 Rev C |
| asbuilt_opening_panel | S14 | 2026 federated model opening S14-O1 (field-cut after erection, stations 194.5-202.5 ft, 8.0 ft wide x 12.0 ft high); not on PC-S02 Rev 2 or the 2024 schedule |
| asd_combination | 0.6W | criteria 3.3 (all reported quantities ASD) |
| omega_d | 2.35 | CDS-B36 Diaphragm Design Manual, Note 2 |
| analysis_method | semi-rigid (DIAPH-MT 1.0) | criteria section 9 and NDDC-AHJ-014 s.3; bilinear membrane FE diaphragm on pier springs |
| mesh_level | L2 | criteria 9.1 and 9.7 (H = 5.0 ft; L2-L3 change of W01 line W reaction 0.15 %) |

## 2. Governing wind scenario for each wall line

| line | governing scenario |
|---|---|
| S | W05 |
| E | W03 |
| N1 | W01 |
| W | W07 |
| N2 | W01 |
| E2 | W07 |

The governing scenario of a wall line is the scenario giving the largest roof-level line load on that line (criteria 6.4; ShearWalls schedule line_load_plf). The scenarios giving the largest ASD shear wall reaction (in-plane load the line takes out of the diaphragm) are also tabulated below for the connection design.

| wall line | largest ASD line load (plf) | at scenario | largest ASD reaction (kips) | at scenario |
|---|---|---|---|---|
| S | 253.0 | W05 | 32.07 | W07 |
| E | 253.4 | W03 | 22.47 | W10 |
| N1 | 321.8 | W01 | 14.44 | W06 |
| W | 252.3 | W07 | 47.62 | W01 |
| N2 | 265.7 | W01 | 20.03 | W04 |
| E2 | 264.0 | W07 | 45.09 | W01 |

## 3. Conflicts between issued documents and how they were resolved

1. **Mechanical screen wall height.** The 2024 precast panel schedule PC-S01 (not reissued) shows panels N108-N111 with top of panel 31.00 ft, and the PC-S02 Rev 2 elevations draw the whole north elevation at 31.00 ft. The roof line scan SR-2026-118 s.5.2, the 2026 federated model and A-101/A-301 Rev C give 36.00 ft (8.00 ft above the 28.00 ft deck) between x = 96 and x = 168 ft. Resolved per criteria 5.3 and transmittal T-204 item 10: the as-built model and scan govern; the screen wall parapet strips N108-P to N111-P were loaded with q_p evaluated at 36.00 ft and lever factor z/h = 32/28, and the panel self weight for stability uses the 36.00 ft gross height.

2. **Field-cut opening in S14.** The federated model carries opening S14-O1 (8.0 ft x 12.0 ft, stations 194.5 to 202.5 ft, provenance 'field-cut after erection') that is not on the 2024 schedule, PC-S02 Rev 2 or A-301 Rev C. Resolved per criteria 5.3 and PC-S02 note 4: the as-built opening governs. S14 is split into a 2.5 ft leg (192.0-194.5 ft, k = 5.70 kip/in) and a 1.5 ft leg (202.5-204.0 ft) which is narrower than 2.0 ft and is neglected (criteria 5.4). Wall pressures still act on the gross S14 area (criteria 6.3).

3. **Superseded criteria Revision 0.** Rev 0 (archive) used V = 105 mph, Risk Category II, Kzt = 1.00, Ke = 1.0, a rigid distribution and a uniform 3 ft parapet. Resolved: Rev 2 governs (transmittal T-204); V = 115 mph and Risk Category III from NDDC-AHJ-014, Kzt = 1.19 from TS-2026-02, Ke = 0.8670 from the ALTA benchmark, the semi-rigid DIAPH-MT model, and the as-built parapet/screen wall heights.

4. **AHJ letter versus 2024 pre-application memorandum.** The 2024 memorandum referenced 105 mph at Risk Category II; NDDC-AHJ-014 s.4 supersedes it. Resolved: 115 mph, Risk Category III.

5. **Topographic factor.** The 2024 preliminary criteria took Kzt = 1.00 pending a study; TS-2026-02 s.4-5 gives 1.19 and supersedes 1.00. Resolved: Kzt = 1.19 over the whole footprint at all elevations and azimuths.

6. **Roof outline.** A-101 Rev A (archive) shows a 240 ft x 180 ft rectangle. A-101 Rev C, S-201 Rev C and the federated model show the generator yard notch (x 180-240, y 140-180) and the mechanical well opening (x 100-140, y 100-130). Resolved: as-built outline; deck zone areas taken off the as-built outline (Z43 = 1,200 sf per S-201 note 8; Z22 and Z32 = 3,200 sf and Z23 and Z33 = 3,400 sf net of the well); total diaphragm area 39,600 sf.

7. **Hall B (Building A1) lateral study.** It reports 105 mph, Kzt = 1.00, Ke = 1.00, q_h = 18.9 psf, a flexible tributary distribution and a single deck type. It is for another building (T-204 item 15) and was not used for any value.

8. **PC-S02 Rev 1 (archive)** is superseded by Rev 2 and was not used.

9. **Deck stiffness in zone Z22.** CDS-B36 tabulates G' for a 6 ft deck span (Note 4), but SJ-201 note 2 and S-201 show joists doubled to 4 ft on centre in Z22 (deck span 4 ft). Resolved per criteria 7.3: G' x 1.15 in Z22 for stiffness only; the ASD strength is unchanged. The smeared joist rigidity in Z22 uses the 4 ft spacing (EAy = 17,400 kip/ft) per criteria 9.2; elsewhere EAy = 13,920 kip/ft and EAx = 2,900 kip/ft.

10. **Ground elevation for Ke.** The ALTA survey gives the finished floor at 3,940.0 ft and the site benchmark BM-2 at 3,941.02 ft. Criteria 4.4 directs zg from the survey benchmark: zg = 3,941.02 ft (Ke = 0.8670; the finished floor value would give the same Ke to four decimals).

11. **Parapet coefficients.** WT-2026-07 s.6.3 describes +1.5 windward / -1.0 leeward with cosine interpolation for oblique winds, while the issued data file tabulates the GCpn values per patch and azimuth. Resolved per criteria 6.1 and WT-2026-07 s.7: the issued data file values were used as tabulated.

12. **Internal pressure.** The enclosure gives GCpi = +/-0.18, but per criteria 4.1 and WT-2026-07 s.6.4 internal pressure cancels in the main wind force resisting system and was excluded from the diaphragm and shear wall loads.

13. **Embed spacing count.** KRS-CN 2.3 sets embeds at not more than 8 ft on centre with a minimum of two per panel. Spacing count = max(2, ceil(L/8)) (2 for 10-12 ft panels, 3 for 20-24 ft panels), increased where the panel roof-level shear (envelope of all scenarios and of a per-panel load distribution check, with a 2 % margin) needs more at 4.20 kips per embed.

14. **Deflection criteria.** Criteria 2 takes the more restrictive of the code and UFC 3-301-01 Table 2-1 (adopted for the campus). UFC Table 2-1 limits apply to framing supporting exterior wall finishes and do not set a diaphragm limit; the OBD 4.4 value of 0.55 in for the diaphragm relative to its supports (criteria 8.2) and h/400 for pier drift (criteria 8.3) were applied to every scenario and both axes.

15. **Risk category.** UFC 3-301-01 Table 2-2 is adopted for the campus risk categories, while NDDC-AHJ-014 accepts Risk Category III for Building A2. Resolved per criteria 2: Risk Category III per the AHJ letter, with the basic wind speed of 115 mph that the AHJ determined at that risk category (the wind speed is the only effect of the risk category on this wind package).

16. **Line load distribution.** Criteria 6.4 defines one roof-level line load per wall line (sum of R_roof over the line's patches per foot of wall); it was applied as a uniform load along each line (criteria 9.5). As a robustness check the deck, chord, deflection, B1, tie-down and embed checks were also satisfied with each panel's R_roof applied over its own length (screen wall load concentrated on N108-N111).

## 4. Load basis

* Code: 2021 IBC (Montana, ARM 24.301.131) with ASCE/SEI 7-16; Risk Category III (NDDC-AHJ-014).
* V = 115 mph, Exposure C, Kd = 0.85, Kzt = 1.19, Ke = 0.8670; q(z) = 0.00256 Kz Kzt Kd Ke V^2 with Kz = 2.01 (z/900)^(2/9.5).
* q_h = 28.74 psf at 28.00 ft; q_p = 29.37 psf at 31.00 ft parapets; q_p = 30.31 psf at the 36.00 ft screen wall (strength level).
* Wall patch pressure p = q_h Cp on the gross panel area of bands B1-B4; parapet p = q_p GCpn on the strip from the deck to the top of each panel; each panel spans foundation to deck, R_roof = p A z/h with h = 28.00 ft (parapets: z/h = 29.5/28 = 1.054 at 31 ft tops, 32/28 = 1.143 at the screen wall). Line load = sum of R_roof / line length, acting along the inward normal.
* Torsional cases W09-W12: all line loads x 0.75 plus M_T = +/-0.15 B |F| (B = 240 ft for N wind, 180 ft for E wind), applied as nodal forces proportional to tributary area and radius from the diaphragm centroid (114.55, 85.00) ft; positive e = counter-clockwise M_T (right-hand rule about +Z, X east, Y north).
* Reported quantities = 0.6 x strength-level wind effect (ASD).

## 5. Analysis

DIAPH-MT 1.0 per criteria section 9, implemented and verified against VE-1 (240 elements / 273 nodes, resultant 20.00 kips, reactions 10.00 / 10.00 kips, largest unit shear 185.2 plf, largest chord bar force 2.57 kips, largest Y displacement 0.1669 in - all reproduced). Building model: structured square mesh from the grid origin, H = 10 / 5 / 2.5 ft; bilinear membrane elements (2x2 Gauss) with Ghat = 12 G' per zone, EAx = 2,900 kip/ft (girders), EAy = 13,920 kip/ft (joists at 5 ft; 17,400 kip/ft in Z22); chord/collector bars with Es = 29,000 ksi; 73 pier springs (legs >= 2.0 ft) at the mesh node nearest each leg mid-point; consistent nodal line loads. Reported at L2 (1584 elements). Mesh convergence of the W01 line W reaction L2-L3: 0.15 % (limit 5 %).

Unit shear at a report station (0.25 / 0.50 / 0.75 of each line, measured from the low-coordinate end of the line: S, N1 and N2 from their west end, E, W and E2 from their south end) is the unit shear of the edge element nearest the station; every station falls on an element boundary at L2, and the exact tie is resolved to the first element in element order (the edge element on the low-coordinate side of the station).

## 6. Design summary

| zone | deck | G' used (kip/in) | ASD capacity (plf) | max ASD unit shear (plf) | area (sf) | cost (USD) |
|---|---|---|---|---|---|---|
| Z11 | D22-36/4-2 | 17.80 | 417.0 | 360.4 | 3600 | 10980.00 |
| Z12 | D16-36/9-4 | 69.30 | 1966.0 | 385.1 | 3600 | 21672.00 |
| Z13 | D22-36/4-2 | 17.80 | 417.0 | 348.5 | 3600 | 10980.00 |
| Z21 | D22-36/4-2 | 17.80 | 417.0 | 179.2 | 3600 | 10980.00 |
| Z22 | D22-36/4-2 | 20.47 | 417.0 | 173.3 | 3200 | 9760.00 |
| Z23 | D22-36/7-4 | 32.60 | 842.6 | 234.6 | 3400 | 13430.00 |
| Z31 | D22-36/4-2 | 17.80 | 417.0 | 178.0 | 3600 | 10980.00 |
| Z32 | D22-36/4-2 | 17.80 | 417.0 | 287.7 | 3200 | 9760.00 |
| Z33 | D20-36/9-4 | 46.10 | 1268.1 | 752.3 | 3400 | 16218.00 |
| Z41 | D22-36/7-4 | 32.60 | 842.6 | 392.4 | 3600 | 14220.00 |
| Z42 | D22-36/7-4 | 32.60 | 842.6 | 248.3 | 3600 | 14220.00 |
| Z43 | D22-36/4-2 | 17.80 | 417.0 | 381.1 | 1200 | 3660.00 |

Distinct deck types: 4 (D16-36/9-4, D20-36/9-4, D22-36/4-2, D22-36/7-4); OBD 4.6 limit 4.

| chord / collector | section | length (ft) | max ASD force (kips) | allowable T / C (kips) | cost (USD) |
|---|---|---|---|---|---|
| C-S | PL3x3/8 | 240.0 | 1.73 | 33.8 / 20.3 | 2619.72 |
| C-N1 | PL3x3/8 | 180.0 | 2.98 | 33.8 / 20.3 | 1964.79 |
| C-N2 | PL3x3/8 | 60.0 | 8.78 | 33.8 / 20.3 | 654.93 |
| C-E | PL3x3/8 | 140.0 | 1.17 | 33.8 / 20.3 | 1528.17 |
| C-E2 | PL12x1 | 40.0 | 21.04 | 360.0 / 216.0 | 4651.20 |
| C-W | PL3x3/8 | 180.0 | 1.43 | 33.8 / 20.3 | 1964.79 |
| K-N2 | PL3x3/8 | 180.0 | 6.56 | 33.8 / 20.3 | 1964.79 |
| K-E2 | PL3x3/8 | 140.0 | 8.16 | 33.8 / 20.3 | 1528.17 |
| O-S | PL3x3/8 | 40.0 | 2.44 | 33.8 / 20.3 | 436.62 |
| O-N | PL3x3/8 | 40.0 | 2.84 | 33.8 / 20.3 | 436.62 |
| O-W | PL3x3/8 | 30.0 | 1.56 | 33.8 / 20.3 | 327.47 |
| O-E | PL3x3/8 | 30.0 | 1.71 | 33.8 / 20.3 | 327.47 |

Embeds: 140 E1 embeds; tie-downs: 7 T1 assemblies on panels N201, N202, E201, E202, E203, E204, N112.

Maximum diaphragm deflection relative to supports: 0.512 in (limit 0.55 in). Maximum pier drift 0.0390 in (limit h/400 = 0.84 in). Highest B1 base shear ratio 0.933 (panel E201).

Installed cost of the lateral package: **USD 208314.73** (OBD 4.7 cap USD 310,000).
